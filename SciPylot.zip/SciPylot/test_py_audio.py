"""
This plot displays the audio spectrum from the microphone.

Based on updating_plot.py
"""
# Standard library imports
import sys

# Major library imports
from pyaudio import PyAudio, paInt16
NUM_SAMPLES = 1024
SAMPLING_RATE = 11025
SPECTROGRAM_LENGTH = 100


##def onTimer(self, event):
##    spectrum, time = get_audio_data()
##    self.spectrum_data.set_data('amplitude', spectrum)
##    self.time_data.set_data('amplitude', time)
##    spectrogram_data = self.spectrogram_plotdata.get_data('imagedata')
##    spectrogram_data = hstack((spectrogram_data[:,1:], transpose([spectrum])))
##
##    
##    self.spectrogram_plotdata.set_data('imagedata', spectrogram_data)
##    self.spectrum_plot.request_redraw()
##    return


def get_audio_data():
        pa = PyAudio()
        stream = pa.open(format=paInt16, channels=1, rate=SAMPLING_RATE, input=True,
                         frames_per_buffer=NUM_SAMPLES, input_device_index = 4)
        string_audio_data = stream.read(NUM_SAMPLES)
        audio_data  = fromstring(string_audio_data, dtype=short)
        normalized_data = audio_data / 32768.0
        return (abs(fft(normalized_data))[:NUM_SAMPLES/2], normalized_data)
        

spectrum, time = get_audio_data()
plot(spectrum)

# EOF
