import numpy as np
from tools import cubspl, pchim, ntervals, evaluate
#from junk import cubspl, pchim, ntervals, evaluate
class piecewise_poly:
    uniform=False
    degree=None
    c=None
    xtab = None
   
    def ppval(self,x, warnings=False):
        """basic method to evaluate piecewise polynomials of the same degree"""
        the_shape = np.shape(x)
        if self.uniform:
            xtab=self.xtab
            h=self.xtab[1]-self.xtab[0]
            idx=np.int16(np.floor((x-xtab[0])/h))
            ntab=len(self.xtab)-1
            p1 = np.array(idx>ntab)
            p2 = np.array(idx<0)
            p3 = np.array(x==xtab[ntab])
            idx[p1]=ntab-1
            idx[p3]=ntab-1
            idx[p2]=0
            if np.linalg.norm(p1+p2)>0 and warnings:
                print "warning: evaluation outside interploation interval"
        else:
            idx,p1 = ntervals(self.xtab,x)
            idx = idx-1        
            if np.linalg.norm(p1)>0 and warnings:
               print "warning: evaluation outside interploation interval"

        return np.reshape(evaluate(self.c[:,idx].T,x-self.xtab[idx]), the_shape)
   
class spline(piecewise_poly):
    """routine for spline interpolation"""
    
    def __init__(self,xtab,ytab, type=None, deriv=None, deriv_values=None):
        a = xtab.flatten()
        b = ytab.flatten()
        if np.size(xtab)==1:
            raise NameError, 'You must have two or more x values'
 #           print 'You must have two or more x values'
 #           self=None
 #           return None
        
        ind = np.lexsort((b,a))
        a=np.take(a,ind)
        b=np.take(b,ind)
        a=np.unique(a)
        if np.size(a)!=np.size(xtab):
            raise NameError, 'x values must be unique'

        if type=="natural":
            deriv=[2,2]
            deriv_values=np.array([0.0,0.0])
        elif type=="clamped":
            deriv=[1,1]
            if deriv_values==None:
                raise NameError, "For clamped conditions you must specify 'deriv_values=[d_0,d_N]'"
                
        elif type==None and deriv==None:
            if np.size(a)==2:
                deriv=[2,2]
            else:    
                deriv = [0,0]
            
            if deriv_values!=None:
                raise NameError, "You need to specify 'deriv=[degree_0,degree_N]' if you give 'deriv_values'"
                
            else:        
                deriv_values = np.array([0.0,0.0])   
                    
        self.degree=3
        self.xtab=a
        dh=np.diff(a,2)
        if np.linalg.norm(dh)<1.0E-07:
            self.uniform=True
        else:
            self.uniform=False
        
        self.c=cubspl(a,b,deriv_values,deriv[0], deriv[1])
        self.c[2,:]/=2    
        self.c[3,:]/=6                         
            
class pchip(piecewise_poly):
    """routine to perform piecewise cubic Hermite interpolation"""
    def __init__(self,xtab,ytab):
        a = xtab.flatten()
        b = ytab.flatten()
        if np.size(xtab)==1:
            raise NameError, 'You must have two or more x values'
 #           print 'You must have two or more x values'
 #           self=None
 #           return None
        if np.size(xtab)!=np.size(ytab):
            raise NameError, 'x and y arrays must be the same size'
        
        ind = np.lexsort((b,a))
        a=np.take(a,ind)
        b=np.take(b,ind)
        a=np.unique(a)
        if np.size(a)!=np.size(xtab):
            raise NameError, 'x values must be unique'
                   
        self.degree=3
        self.xtab=a
        dh=np.diff(a,2)
        if np.linalg.norm(dh)<1.0E-07:
            self.uniform=True
        else:
            self.uniform=False
        h=np.diff(a)
        D1=pchim(a,b.reshape([1,len(b)]))
        D1=D1.flatten()
        DELTA = (np.diff(b))/h
        DEL1 = (D1[:-1] - DELTA)/h
        DEL2 = (D1[1:] - DELTA)/h
        C2=-(DEL1+DEL1 + DEL2)
        C3 = (DEL1 + DEL2)/h 
        self.c=np.vstack((b[:-1],D1[:-1],C2,C3))      

def ppval(c,x):
    if c.c==None:
        raise NameError, 'First argument "c" must be created with "spline" or "pchip" '
    else:
        if np.isscalar(x):
            return (c.ppval(np.array([x])))[0]
        else:
            return c.ppval(x)


def lin_eq_solve(f,neq):
    """This function calculates the solution of a linear system
    of equations 0 = A*x - b defined by user function F(x).
    In particular, F must take an argument xeval and
    calculate A*xeval - b, and then F must return this
    as an array with neq elements.
    INPUT ARGUMENTS:
    f is the name of a function supplied by the user.
    neq is the number of equations (unknowns)
    RETURN ARGUMENTS:
    solution of system in x
    
    The system is recovered by making neq + 1 calls to f.
    The first call passes a column of zeros to get (-b).
    The remaining neq calls recover AminusB = A - b*ones(1, neq)
    by setting one entry of xeval to 1 and remainders to zero.
    A is calculated by adding b to each column of C
    
    Once A and b are known, solution using np.linalg.solve(A,b)
    """
    xeval = hstack([zeros((neq,1)), eye(neq)])#
    A1=zeros((neq,neq+1)) #preallocate A1 for ML efficiency
    #function evaluations
    for k in arange(neq+1):
        A1[:,k] = f(xeval[:,k])# evalauate F one column at a time
    # 'feval' is a MATLAB function for evaluating a user function
    # passed as an argument to another user function

    b = -A1[:,0]#extract b
    B=reshape(b,(neq,1))*ones((1, neq))# create matrix with neq identical columns
    AminusB = A1[:,1:neq+1]#extract A-B
    A = AminusB+B # Create A by adding B to A-B 
    #solve system
    x = np.linalg.solve(A,b) # calculate x with no error checks
    return x
    ##end                 