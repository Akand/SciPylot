from enthought.mayavi.sources.vtk_data_source import VTKDataSource
from enthought.mayavi.modules.surface import Surface
from enthought.tvtk.api import tvtk
import numpy as np
from math import atan2


def patch(points = None, polys=None,  color=(1,1,1), opacity=.8,
          show_edges=False, scalars=None, edge_color=(0,0,0), aprop=None, name=None,
        colormap=None): 
    points=np.float32(points)
    polys=np.int(polys)
    mesh = tvtk.PolyData(points=points, polys=polys)
    mesh.point_data.scalars = scalars
    #mesh.point_data.scalars.name = 'Temperature'
    src = VTKDataSource(data = mesh)
    e=p3d.get_engine()
    e.add_source(src)
    #s = Surface()
    #e.add_module(s)
    asurf=p3d.pipeline.surface(src,opacity=.7)
    p3d.pipeline.surface(p3d.pipeline.extract_edges(src),color=(0,0,0),)
    aprop=tvtk.RIBProperty()
    aprop.ambient = 0.3            # "Ka"  -ambient strength
    aprop.diffuse = 0.3            # "Kd" -diffuse strength
    aprop.specular = 0.55          # "Ks"   -  specular intensity
    aprop.specular_power = 5.0    # n = specular exponent 1/roughness in the RIB file
    aprop.specular_color=[.5, .5, .5]        # sc =specular_color_reflectance (0==all object color, 1 is all light color)
    aprop.interpolation='phong'    #or 'flat' or gouraud
    asurf.actor.property=aprop
    """materials properties
    material       ka     kd    ks    a    sc
    'Shiny'        0.3    0.6   0.9  20    1.0
    'Dull'         .3      .8   0.0  10    1.0
    'Metal'        .3      .3   1.0  25     .5"""
    
    
def az_el_from_position (x,y,z):
    """ Given the position vector, return an elevation and azimuth
    angle (in degrees).
    theta = atan2(x, z)
    phi = atan2(sqrt(x**2+z**2), y)
    az = theta*180.0/pi
    el = 90.0 - phi*180.0/pi
    return el, az"""
    theta = atan2(x, z)
    phi = atan2(sqrt(x**2+z**2), y)
    az = theta*180.0/pi
    el = 90.0 - phi*180.0/pi
    return el, az


    