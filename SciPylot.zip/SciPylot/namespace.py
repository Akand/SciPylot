from matplotlib.pyplot import *
import matplotlib.pyplot as pp
from scipy import *
import scipy as sp
import numpy as np
import scipy.ndimage as ndimage
import scipy.stats as stats
import scipy.signal as signal
import scipy.lib as lib
try:
    import scipy.linsolve as linsolve
except:
    import scipy.sparse.linalg.dsolve.linsolve as linsolve
import scipy.misc as misc
import scipy.misc as misc
import scipy.sparse as sparse
import scipy.interpolate as interpolate
import scipy.optimize as optimize
#import scipy.cluster as cluster
#import scipy.linsolve.umfpack as umfpack
import scipy.fftpack as fftpack
import scipy.odr as odr
import scipy.io as io
import scipy.maxentropy as maxentropy
import scipy.integrate as integrate
import scipy.lib.lapack as lapack
import scipy.special as special
import scipy.lib.blas as blas
try:
    from sp_tools import ppval, pchip, spline, lin_eq_solve
except:
    pass    

from enthought.mayavi import mlab as p3d
from enthought.tvtk.api import tvtk

sp.ndimage = ndimage
sp.stats=stats
sp.signal=signal
sp.lib=lib
sp.linsolve=linsolve
sp.misc=misc
sp.misc=misc
sp.sparse=sparse
sp.interpolate=interpolate
sp.optimize=optimize
sp.fftpack=fftpack
sp.odr=odr
sp.io=io
sp.maxentropy=maxentropy
sp.integrate=integrate
sp.lapack=lapack
sp.special=special
spblas=blas

def import_table(text,col=1):
    """import a table of numbers to an array
    without worrying about commas
   
    text = an array enclosed in triple quotes
    col = int number of columns"""
    x=sp.mat(text)
    x=x.__array__()
    x=reshape(x,[-1,col])
    return x
    
def fzero(func, x0,fprime=None, args=(), tol=1.48e-008, maxiter=50):
    #just a wrapper to scipy.optimize.newton
    return optimize.newton(func, x0,fprime=None, args=(), tol=1.48e-008, maxiter=50)
try:
    del x #get rid of this pyplot name
except:
    pass
