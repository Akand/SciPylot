modules={}


def getmodules(p):
    # get modules in a given directory
    modules = {}
    for f in os.listdir(p):
        f = os.path.join(p, f)
        if os.path.isfile(f):
            m, e = os.path.splitext(f)
            suffix = get_suffix(f)
            if not suffix:
                continue
            m = os.path.basename(m)
            if re.compile("(?i)[a-z_]\w*$").match(m):
                if suffix[2] == imp.C_EXTENSION:
                    # check that this extension can be imported
                    try:
                        __import__(m)
                    except ImportError:
                        continue
                modules[m] = f
        elif os.path.isdir(f):
            m = os.path.basename(f)
            if os.path.isfile(os.path.join(f, "__init__.py")):
                for mm, f in getmodules(f).items():
                    modules[m + "." + mm] = f
    return modules

#path = map(os.path.normcase, map(os.path.abspath, sys.path[:]))

path=['c:\\python25\\lib\\site-packages\\etplib-4.0.0.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\windows_extras-1.0.1.0001_s-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\scite-1.74.0003-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pywin32-210.0001_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pyreadline-1.4.4.dev_r0.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\mingw-3.4.5.0001_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\zlib-1.2.3.0004_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\lapack_lite-3.1.1.0003-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\zope.testing-3.5.4.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\zope.proxy-3.4.2.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\zope.interface-3.4.1.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\zodb3-3.8.0.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\zdaemon-2.0.2.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\zconfig-2.5.1.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\wx-2.8-msw-unicode', 
'c:\\python25\\lib\\site-packages\\wininst-1.2.3.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\vtk-5.0.4.0001_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\twisted-8.1.0.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\testoob-1.13.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\swig-1.3.36.0001_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\sqlalchemy-0.4.6.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\sphinx-0.4.2.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\soappy-0.11.6.0002-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\simplejson-1.9.2.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\scons-0.98.5.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\scientificpython-2.7.6.0006_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\reportlab-2.1.0004-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyxml-0.8.4.0003-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pytz-2008c.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\python_dateutil-1.4.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pytables-2.0.4.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pysvn-1.5.1.0003-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pyserial-2.4.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyrex-0.9.5.1a.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyproj-1.8.5.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pyparsing-1.5.0.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyopenssl-0.7.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pyopengl-3.0.0b5.0001_s-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyhdf-0.8.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pygments-0.10.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyglet-1.0.0003-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pygarrayimage-0.0.5.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pydot-1.0.2.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pycrypto-2.0.1.0002-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pycdf-0.6_3b.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pyaudio-0.2.0.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\portaudio-19.0004-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\ply-2.5.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pil-1.1.6.0004_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\numarray-1.5.2.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\nose-0.10.3.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\networkx-0.36.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\netcdf-3.6.2.0005-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\mysql_python-1.2.2.0003-py2.5-win32.egg',
 'c:\\python25\\lib\\site-packages\\mpi4py-0.6.0.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\lxml-2.1.1.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\jinja-1.2.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\ipython-0.9.beta.0001_s-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\hdf5-1.8.1.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\hdf4-4.2r3.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\grin-1.1.1.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\graphviz-2.20.2.0001_s-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\gadfly-1.0.0.0004-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\freetype-2.3.7.0001-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\fpconst-0.7.2.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\epydoc-3.0.1.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\docutils-0.5.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\coverage-2.80.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\configobj-4.5.3.0001-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\argparse-0.8.0.0001-py2.5.egg', 
#'c:\\python25\\lib\\site-packages\\ets-3.0.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\traitsgui-3.0.1-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\traitsbackendwx-3.0.1-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\traitsbackendqt-3.0.1-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\traits-3.0.1-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\scimath-3.0.0-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\mayavi-3.0.0-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\etsprojecttools-0.4.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\etsdevtools-3.0.0-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\envisageplugins-3.0.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\envisagecore-3.0.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\enthoughtbase-3.0.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\enable-3.0.0-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\chaco-3.0.0-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\codetools-3.0.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\blockcanvas-3.0.0-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\apptools-3.0.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\trac-0.11.1-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\genshi-0.5.1-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\matplotlib-0.98.3-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\dap-2.2.6.6-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\httplib2-0.4.0-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\winpdb-1.3.6-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\pyprotocols-0.9.3-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\dice3ds-0.10-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\mercurial-1.1.2-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\bbfreeze-0.96.5-py2.5-win32.egg', 
'c:\\python25\\lib\\site-packages\\pefile-1.2.10_63-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\altgraph-0.6.7-py2.5.egg', 
'c:\\python25\\lib\\site-packages\\yolk-0.4.1-py2.5.egg', 
'c:\\windows\\system32\\python25.zip', 'c:\\python25\\dlls', 
'c:\\python25\\lib', 'c:\\python25\\lib\\plat-win', 
'c:\\python25\\lib\\lib-tk', 'c:\\python25', 'c:\\python25\\lib\\site-packages', 
'c:\\python25\\lib\\site-packages\\pil-1.1.6.0004_s-py2.5-win32.egg\\pil', 
'c:\\python25\\lib\\site-packages\\pywin32-210.0001_s-py2.5-win32.egg\\win32', 
'c:\\python25\\lib\\site-packages\\pywin32-210.0001_s-py2.5-win32.egg\\win32\\lib', 
'c:\\python25\\lib\\site-packages\\pywin32-210.0001_s-py2.5-win32.egg\\pythonwin', 
'c:\\python25\\lib\\site-packages\\mayavi-3.0.0-py2.5-win32.egg\\enthought\\tvtk\\tvtk_classes.zip']

for p in path:
    try:
        modules.update(getmodules(p))
    except:
        print "exception on"+p 
        
the_keys=modules.keys()
the_keys.sort()
file=open('module_list.txt','w')
text1='\n'.join(the_keys)
file.write(text1)
file.close()
