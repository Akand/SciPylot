import matplotlib
if matplotlib.get_backend()!='WXAgg':
    matplotlib.use('WXAgg')
import os
import sys
import shutil
cur_dir=sys.path[0]
os.chdir(cur_dir)
import wx
import wx.stc as wx_stc
import wx.grid
import wx.html
import wx.aui
import crust_aui
import cStringIO
import stc
import tempfile
#importing printing options
import Printer
reload(Printer)
from Printer import Printer


matplotlib.interactive(True)
matplotlib.rc('verbose', level='silent')

#import matlab_editor_command as m_ed
#import matplotlib.pyplot as pp
import namespace
from enthought.traits.api import HasTraits, Instance
from enthought.traits.ui.api import View, Item
from enthought.tvtk.pyface.scene_editor import SceneEditor
from enthought.mayavi.tools.mlab_scene_model import MlabSceneModel



if wx.Platform == '__WXMSW__':
    from wx.lib.iewin_old import IEHtmlWindow as  Html_Viewer
    Html_Viewer.LoadPage=Html_Viewer.LoadUrl
    file_sep="\\"
    from win32com.shell import shellcon as shellconwin
    from win32com.shell import shell as shellwin
    homedir = shellwin.SHGetFolderPath(0, shellconwin.CSIDL_APPDATA, 0, 0)

elif wx.Platform == '__WXMAC__':
    from wx.webkit import WebKitCtrl as Html_Viewer
    Html_Viewer.LoadPage=Html_Viewer.LoadURL
    file_sep='/' 
    homedir = os.path.expanduser("~")    
else:
    from wx.html import HtmlWindow as Html_Viewer
    file_sep='/'    
    homedir = os.path.expanduser("~") 

 

import crust_aui
from xml.sax.handler import ContentHandler
from xml.sax import parse
import time
import webbrowser
#from pdfwin3 import PDFWindow
#from wx.lib.pdfwin_old import PDFWindow

#destroy_app=True
wildcard = "Python source (*.py)|*.py|"     \
           "Matlab/Octave (*.m|*.m|"   \
           "Compiled Python (*.pyc)|*.pyc|" \
           "All files (*.*)|*.*"



if wx.Platform == '__WXMSW__':
    faces = { 'times': 'Times New Roman',
              'mono' : 'Courier New',
              'helv' : 'Arial',
              'other': 'Comic Sans MS',
              'size' : 10,
              'size2': 10,
             }
else:
    faces = { 'times': 'Times',
              'mono' : 'Courier',
              'helv' : 'Helvetica',
              'other': 'new century schoolbook',
              'size' : 12,
              'size2': 12,
             }

zoom_levels=[('Largest',6),('Larger',4),('Large',2), ('normal',0), ('small',-1),('smaller',-2), ('smallest',-3)]
zoom_levels=dict(zoom_levels)
default_layout="layout2|name=help;caption=Documents and Help;state=6293500;dir=4;layer=1;row=0;pos=0;prop=100325;bestw=20;besth=20;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=619;floaty=609;floatw=33;floath=50|name=workspace;caption=Control Pane;state=6293500;dir=4;layer=1;row=0;pos=1;prop=99675;bestw=200;besth=200;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=650;floaty=619;floatw=208;floath=230|name=editor;caption=Editor Pane;state=6293500;dir=1;layer=0;row=1;pos=0;prop=100000;bestw=20;besth=20;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=624;floaty=216;floatw=33;floath=50|name=settings;caption=Dock Manager Settings;state=2099199;dir=4;layer=1;row=0;pos=2;prop=100000;bestw=479;besth=185;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=496;floaty=313;floatw=487;floath=215|name=crust_panel;caption=;state=768;dir=5;layer=0;row=0;pos=0;prop=100000;bestw=20;besth=20;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=-1;floaty=-1;floatw=-1;floath=-1|name=sptb;caption=SciPylot Toolbar;state=2108144;dir=1;layer=10;row=0;pos=0;prop=100000;bestw=451;besth=29;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=-1;floaty=-1;floatw=-1;floath=-1|name=sptb_tools;caption=SciPylot Toolbar Tools;state=2108144;dir=1;layer=10;row=0;pos=462;prop=100000;bestw=87;besth=29;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=-1;floaty=-1;floatw=-1;floath=-1|name=sptb_2D;caption=SciPylot Toolbar 2D;state=2108144;dir=1;layer=10;row=0;pos=560;prop=100000;bestw=87;besth=29;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=-1;floaty=-1;floatw=-1;floath=-1|name=sptb_3D;caption=SciPylot Toolbar 3D;state=2108144;dir=1;layer=10;row=0;pos=658;prop=100000;bestw=116;besth=29;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=-1;floaty=-1;floatw=-1;floath=-1|dock_size(5,0,0)=22|dock_size(1,10,0)=31|dock_size(1,0,1)=588|dock_size(4,1,0)=470|"
#File Menu ID's
ID_New=wx.NewId()
ID_OpenFile=wx.NewId()
ID_Save = wx.NewId()
ID_SaveAs = wx.NewId()
ID_SaveAll = wx.NewId()
ID_OpenWorkspace=wx.NewId()
ID_SaveWorkspace=wx.NewId()
ID_PrintInputFile = wx.NewId()
ID_PrintOutputFile = wx.NewId()
ID_RecentFiles=wx.NewId()
ID_Exit = wx.NewId()
        
        

#Edit Menu ID's
ID_Undo=wx.NewId()
ID_Redo=wx.NewId()
ID_Copy=wx.NewId()
ID_Cut=wx.NewId()
ID_Paste=wx.NewId()
ID_PasteRectangle=wx.NewId()
ID_SelectRectangle=wx.NewId()
ID_SelectAll=wx.NewId()
ID_Indent=wx.NewId()
ID_Dedent=wx.NewId()
ID_Comment=wx.NewId()
ID_Uncomment=wx.NewId()
ID_Find=wx.NewId()
ID_FindAgain=wx.NewId()
ID_Replace=wx.NewId()


#Tools Menu
ID_RunInShell=wx.NewId()
ID_RunExternally=wx.NewId()
ID_ImportInShell=wx.NewId()
ID_Debug=wx.NewId()
ID_Profile=wx.NewId()
#View Menu
ID_Whitespace=wx.NewId()
ID_IndentationGuides=wx.NewId()
ID_RightEdgeIndicator=wx.NewId()
ID_EndOfLineMarker=wx.NewId()
ID_EditPane=wx.NewId()
ID_ControlPane=wx.NewId()
ID_HelpPane=wx.NewId()
ID_FigurePane=wx.NewId()
ID_ZoomIn=wx.NewId()
ID_ZoomOut=wx.NewId()
ID_ZoomFactor=wx.NewId()



#Toolbar ID's
ID_New_TB=wx.NewId()
ID_OpenFile_TB=wx.NewId()
ID_Save_TB = wx.NewId()
ID_Print_TB = wx.NewId()

ID_Undo_TB=wx.NewId()
ID_Redo_TB=wx.NewId()
ID_Copy_TB=wx.NewId()
ID_Cut_TB=wx.NewId()
ID_Paste_TB=wx.NewId()
ID_Indent_TB=wx.NewId()
ID_Dedent_TB=wx.NewId()
ID_Comment_TB=wx.NewId()
ID_Uncomment_TB=wx.NewId()
ID_Find_TB=wx.NewId()
ID_Replace_TB=wx.NewId()

#Toolbar View Menu
ID_Whitespace_TB=wx.NewId()
ID_IndentationGuides_TB=wx.NewId()
ID_RightEdgeIndicator_TB=wx.NewId()
ID_EndOfLineMarker_TB=wx.NewId()
ID_ZoomIn_TB=wx.NewId()
ID_ZoomOut_TB=wx.NewId()
ID_ZoomFactor_TB=wx.NewId()

ID_RunInShell_TB=wx.NewId()
ID_RunExternally_TB=wx.NewId()
ID_ImportInShell_TB=wx.NewId()
ID_Debug_TB=wx.NewId()

ID_ResetNamespace=wx.NewId()

ID_ClearShell=wx.NewId()
ID_pySketch=wx.NewId()
ID_OnEmbed2DFigure=wx.NewId()
ID_OnClick3DtoNotebookOn=wx.NewId()

ID_RestoreView_TB=wx.NewId()

ID_Help_TB=wx.NewId()


ID_insert2D_TB=wx.NewId()
ID_copy2D_TB=wx.NewId()
ID_clear2D_TB = wx.NewId()

ID_insert3D_TB=wx.NewId()
ID_copy3D_TB=wx.NewId()
ID_clear3D_TB = wx.NewId()
ID_openPipeline_TB=wx.NewId()

ID_SizeReportContent = wx.NewId()
ID_CreatePerspective = wx.NewId()
ID_CopyPerspective = wx.NewId()

ID_TransparentHint = wx.NewId()
ID_VenetianBlindsHint = wx.NewId()
ID_RectangleHint = wx.NewId()
ID_NoHint = wx.NewId()
ID_HintFade = wx.NewId()
ID_AllowFloating = wx.NewId()
ID_NoVenetianFade = wx.NewId()
ID_TransparentDrag = wx.NewId()
ID_AllowActivePane = wx.NewId()
ID_NoGradient = wx.NewId()
ID_VerticalGradient = wx.NewId()
ID_HorizontalGradient = wx.NewId()

ID_Settings = wx.NewId()

ID_HelpEnv = wx.NewId()
ID_LocalHelp= wx.NewId()
ID_WebHelp= wx.NewId()

ID_About = wx.NewId()


ID_CreateTree = wx.NewId()
ID_CreateGrid = wx.NewId()
ID_CreateText = wx.NewId()
ID_CreateHTML = wx.NewId()
ID_CreateSizeReport = wx.NewId()
ID_GridContent = wx.NewId()
ID_TextContent = wx.NewId()
ID_TreeContent = wx.NewId()
ID_HTMLContent = wx.NewId()

ID_FirstPerspective = ID_CreatePerspective+1000


#http://www.tramy.us/numpybook.pdf #address for Travis O.'s numpy book
#http://www.elisanet.fi/ptvirtan/tmp/numpy-refguide/index.xhtml #numpy Sphinx-generated reference guides
#http://scipy.org/Cookbook  #scipy cookbook
#http://scipy.org/Documentation #scipy documentation
#http://www.scipy.org/Cookbook/Matplotlib?action=show&redirect=wikis%2Ftopical+software%2FMatplotlibCookbook
#http://code.enthought.com/projects/mayavi/docs/development/html/mayavi/  #mayavi docs
#http://code.enthought.com/projects/mayavi/docs/development/html/tvtk/

#----------------------------------------------------------------------

class TheFileDropTarget(wx.FileDropTarget):
    def __init__(self, frame,nb):
        wx.FileDropTarget.__init__(self)
        self.nbeditor = nb
        self.frame=frame

    def OnDropFiles(self, x, y, filenames):
        
        for path in filenames:
        #do not allow more than one instance of file
            for index in xrange(self.nbeditor.GetPageCount()):
                if path==self.nbeditor.GetPage(index).name:
                    self.nbeditor.SetSelection(index)
                    return
    
            if os.path.isfile(path):
                file=os.path.basename(path)
                fid=open(path,'r')
                ftext=fid.read()
                fid.close()
                directory=path[0:path.rfind(os.pathsep)]
                self.frame.OpenEditNotebookPage(directory=directory, name=path,caption=file, text=ftext)
                self.frame.Title = 'SciPylot - '+path
            else:
                pass





class GeneralXMLHandler(ContentHandler):
    """ a class to handle parsing a specific field from a simple xml file
    field_name is the field you want to extract
    field is an empty list at the start, returns a list with
    all field entries from top to bottom in the xml file
        the_files=[]
        parse(fname, WorkspaceHandler(the_files, "file"))"""

    in_field=False
    def __init__(self, field,field_name):
        ContentHandler.__init__(self)
        self.field=field
        self.field_name=field_name
        self.data = []
    def startElement(self,name, attrs):
        if name == self.field_name:
            self.in_field=True
    
    def endElement(self,name):
        if name==self.field_name:
            text = ''.join(self.data)
            self.data=[]
            self.field.append(text)
            self.in_field = False

    def characters(self,string):
        if self.in_field:
            self.data.append(string)   


class MayaviView(HasTraits):

    scene = Instance(MlabSceneModel, ())
    
    view = View(Item('scene', editor=SceneEditor(), resizable=True,
                    show_label=False),
                    resizable=True)

    def __init__(self):
        HasTraits.__init__(self)
##        x, y, z = ogrid[-10:10:100j, -10:10:100j, -10:10:100j]
##        scalars = sin(x*y*z)/(x*y*z)
##        src = ArraySource(scalar_data=scalars)
##        self.scene.engine.add_source(src)
##        src.add_module(IsoSurface())
class RedirectText(object):
    def __init__(self,aWxTextCtrl):
        self.out=aWxTextCtrl
 
    def write(self,string):
        the_shell_end=self.out.GetLength()
        self.out.DocumentEnd()
        command_start=(self.out.GetText()).rfind(str(sys.ps1))
        self.out.SetSelection(command_start-2,the_shell_end)
#        self.out.ReplaceSelection(string)#+'\n'+str(sys.ps1)+" ")
        self.out.ReplaceSelection("")#+'\n'+str(sys.ps1)+" ")
        self.out.push('print r"""'+ string +'"""', silent = False,add_hist=False)


class PyAUIFrame(wx.Frame):

    def __init__(self, parent, id=-1, title="", pos=wx.DefaultPosition, destroy_app=True,
                 size=wx.DefaultSize, layout=default_layout, app=None, style=wx.DEFAULT_FRAME_STYLE |
                                            wx.SUNKEN_BORDER |
                                            wx.CLIP_CHILDREN):

        wx.Frame.__init__(self, parent, id, title, pos, size, style)

        self.main_directory=cur_dir
        self.app=app
        my_path = os.path.join(cur_dir,'cover_cells_reduced24.ico')

        icon    = wx.Icon(my_path,wx.BITMAP_TYPE_ICO)
        self.SetIcon(icon)
        self.NewFileKount=1
        # tell FrameManager to manage this frame
        self._mgr = wx.aui.AuiManager()
        self._mgr.SetManagedWindow(self)
        self.current_layout=layout
#        self.ismaxed=False
#        self.passed_restore=True    
        
        self._perspectives = []
        self.n = 0
        self.x = 0
        self.crustpanel=wx.Panel(self, -1)
        self.nbpanel=wx.Panel(self,-1, size=wx.Size(200, 200))
        self.notebook1=wx.aui.AuiNotebook(self.nbpanel,id=-1,style=wx.aui.AUI_NB_WINDOWLIST_BUTTON|wx.aui.AUI_NB_TAB_MOVE|wx.aui.AUI_NB_TAB_SPLIT|wx.aui.AUI_NB_BOTTOM|wx.aui.AUI_NB_SCROLL_BUTTONS)

        sizer = wx.BoxSizer()
        sizer.Add(self.notebook1, 1, wx.EXPAND)
        self.nbpanel.SetSizer(sizer)
        
        self.help_panel=wx.Panel(self, -1)
        self.help_notebook=wx.aui.AuiNotebook(self.help_panel,id=-1,style=wx.aui.AUI_NB_WINDOWLIST_BUTTON|wx.aui.AUI_NB_TAB_MOVE|wx.aui.AUI_NB_TAB_SPLIT|wx.aui.AUI_NB_CLOSE_ON_ALL_TABS|wx.aui.AUI_NB_LEFT|wx.aui.AUI_NB_SCROLL_BUTTONS)
#        self.help_notebook.AddPage(page=self.CreateHTMLCtrl2(), caption='Documents')
#        self.nbeditor.AddPage(page=m_ed.PythonSTC(self.nbeditor, -1), caption='Input_Cell')
        sizer = wx.BoxSizer()
        sizer.Add(self.help_notebook, 1, wx.EXPAND)
        self.help_panel.SetSizer(sizer)
        self.destroy_app=destroy_app



        if size == wx.DefaultSize:
            self.SetSize((1200, 800))

        self.SetPosition(pos)

#        text = "This is text box 1"
        rootObject=None 
        rootLabel=None 
        rootIsNamespace=True
        InterpClass=None
        config=None 
        dataDir=None



#        self.SetStatusText(intro.replace('\n', ', '))
        self.notebook1.AddPage(page=wx.aui.AuiNotebook(self,id=-1,style=wx.aui.AUI_NB_WINDOWLIST_BUTTON|wx.aui.AUI_NB_TAB_MOVE|wx.aui.AUI_NB_TAB_SPLIT|wx.aui.AUI_NB_LEFT|wx.aui.AUI_NB_SCROLL_BUTTONS),caption="Histories", select=True)
        idx=self.notebook1.GetPageCount()-1
        self.notebook1.SetSelection(idx)
        self.hist_note=self.notebook1.GetPage(idx)
        self.notebook1.SetTabCtrlHeight(1.25*self.notebook1.GetTabCtrlHeight())
        
        
        
        
        
        
        self.hist_note.AddPage(page=wx.grid.Grid(self,-1), caption="ShellHist", select=True)
        idx=self.hist_note.GetPageCount()-1
        self.hist_note.SetSelection(idx)
        self.hist_grid=self.hist_note.GetPage(idx)
        self.hist_grid.CreateGrid(2,2)
        self.hist_grid.last_row=0
        self.hist_grid.SetColSize(0,250)
        self.hist_grid.SetColSize(1,105)

        self.hist_grid.SetColLabelValue(0,'command')
        self.hist_grid.SetColLabelValue(1,'y/m/d  time')
#        self.hist_grid.SetRowLabelSize(40)
        self.hist_grid.AutoSizeRows(True)
        grid_row_height=self.hist_grid.GetRowSize(0)*.90
        self.hist_grid.grid_row_height=grid_row_height


        self.hist_note.AddPage(page=wx.grid.Grid(self,-1), caption="InputHist", select=False)
        idx=self.hist_note.GetPageCount()-1

        self.cell_hist_grid=self.hist_note.GetPage(idx)
        self.cell_hist_grid.CreateGrid(2,2)
        self.cell_hist_grid.last_row=0
        self.cell_hist_grid.SetColSize(0,250)
        self.cell_hist_grid.SetColSize(1,105)

        self.cell_hist_grid.SetColLabelValue(0,'commands')
        self.cell_hist_grid.SetColLabelValue(1,'y/m/d  time')
#        self.hist_grid.SetRowLabelSize(40)
        self.cell_hist_grid.AutoSizeRows(True)


        self.hist_note.AddPage(page=wx.grid.Grid(self,-1), caption="FileHist", select=False)
        idx=self.hist_note.GetPageCount()-1

        self.file_hist_grid=self.hist_note.GetPage(idx)
        self.file_hist_grid.CreateGrid(2,2)
        self.file_hist_grid.last_row=0
        self.file_hist_grid.SetColSize(0,250)
        self.file_hist_grid.SetColSize(1,105)

        self.file_hist_grid.SetColLabelValue(0,'file')
        self.file_hist_grid.SetColLabelValue(1,'y/m/d  time')
#        self.hist_grid.SetRowLabelSize(40)
        self.file_hist_grid.AutoSizeRows(True)


        self.hist_note.AddPage(page=wx.grid.Grid(self,-1), caption="WorkspaceHist", select=False)
        idx=self.hist_note.GetPageCount()-1

        self.workspace_hist_grid=self.hist_note.GetPage(idx)
        self.workspace_hist_grid.CreateGrid(2,2)
        self.workspace_hist_grid.last_row=0
        self.workspace_hist_grid.SetColSize(0,250)
        self.workspace_hist_grid.SetColSize(1,105)

        self.workspace_hist_grid.SetColLabelValue(0,'file')
        self.workspace_hist_grid.SetColLabelValue(1,'y/m/d  time')
#        self.hist_grid.SetRowLabelSize(40)
        self.workspace_hist_grid.AutoSizeRows(True)




        intro = """Welcome to SciPylot. """
        self.crust = crust_aui.Crust(self.crustpanel,-1, notebook=self.notebook1, call_notebook=self.help_notebook,intro=intro, hist_grid=self.hist_grid,
                           rootObject=rootObject,
                           rootLabel=rootLabel,
                           rootIsNamespace=rootIsNamespace,
                           locals=dict(),
                           InterpClass=InterpClass)
        self.shell = self.crust.shell
        redir=RedirectText(self.shell)
        sys.stdout=redir
        sys.stderr=redir

        self.shell.SetKeyWords(1," ".join(namespace.__dict__.keys()))
        self.shell.StyleSetSpec(wx_stc.STC_P_WORD2, "fore:#0000FF,bold,size:%(size)d" % faces)
        # Keyword2
        self.shell.StyleSetSpec(wx_stc.STC_P_WORD, "fore:#00007F,bold,size:%(size)d" % faces)        
#        sizer = wx.BoxSizer()
#        sizer.Add(self.crustpanel, 1, wx.EXPAND)
        
#        self.SetSizer(sizer)

        self.editor_panel=wx.Panel(self, -1)
#        self.nbeditor=wx.aui.AuiNotebook(self.editor_panel,id=-1,style=wx.aui.AUI_NB_TAB_SPLIT|wx.aui.AUI_NB_CLOSE_ON_ALL_TABS|wx.aui.AUI_NB_LEFT)        
        self.nbeditor=wx.aui.AuiNotebook(self.editor_panel,id=-1,style=wx.aui.AUI_NB_WINDOWLIST_BUTTON|wx.aui.AUI_NB_TAB_MOVE|wx.aui.AUI_NB_TAB_SPLIT|wx.aui.AUI_NB_CLOSE_ON_ALL_TABS|wx.aui.AUI_NB_LEFT|wx.aui.AUI_NB_SCROLL_BUTTONS)
        self.nbeditor.AddPage(page=stc.PythonBaseSTC(self,-1, calltip_window=self.crust.calltip,shell=self.crust.shell,name="Input_Cell", namespace=self.crust.shell.interp.locals ,keywordlist=namespace.__dict__),caption='Input_Cell')
        self.nbeditor.GetPage(0).dirty=False
#        self.nbeditor.AddPage(page=m_ed.PythonSTC(self.nbeditor, -1), caption='Input_Cell')
        sizer = wx.BoxSizer()
        sizer.Add(self.nbeditor, 1, wx.EXPAND)
        self.editor_panel.SetSizer(sizer)
        self.drop_target=TheFileDropTarget(self,self.nbeditor)
        self.SetDropTarget(self.drop_target)
        drop_target2=TheFileDropTarget(self,self.nbeditor)
        self.nbeditor.SetDropTarget(drop_target2)
        self.nbeditor.GetPage(0).SetDropTarget(self.drop_target)
#       intitialize environemnt
        if not os.path.isdir(homedir+file_sep+"SciPylot"):
            os.makedirs(homedir+file_sep+"SciPylot")
            shutil.copy2(self.main_directory+file_sep+"external_links.XML",homedir+file_sep+"SciPylot"+file_sep+"external_links.XML")
            shutil.copy2(self.main_directory+file_sep+"history.XML",homedir+file_sep+"SciPylot"+file_sep+"history.XML")
            shutil.copy2(self.main_directory+file_sep+"cell_history.XML",homedir+file_sep+"SciPylot"+file_sep+"cell_history.XML")
            shutil.copy2(self.main_directory+file_sep+"file_history.XML",homedir+file_sep+"SciPylot"+file_sep+"file_history.XML")
            shutil.copy2(self.main_directory+file_sep+"workspace_history.XML",homedir+file_sep+"SciPylot"+file_sep+"workspace_history.XML")

        hist_name=homedir+file_sep+"SciPylot"+file_sep+'history.xml'
        cell_hist_name=homedir+file_sep+"SciPylot"+file_sep+'cell_history.xml'
        file_hist_name=homedir+file_sep+"SciPylot"+file_sep+'file_history.xml'
        workspace_hist_name=homedir+file_sep+"SciPylot"+file_sep+'workspace_history.xml'
        ext_name= homedir+file_sep+"SciPylot" +file_sep+'external_links.xml'
        if not os.path.isfile(hist_name):
            shutil.copy2(self.main_directory+file_sep+"history.XML",homedir+file_sep+"SciPylot"+file_sep+"history.XML")
        if not os.path.isfile(cell_hist_name):
            shutil.copy2(self.main_directory+file_sep+"cell_history.XML",homedir+file_sep+"SciPylot"+file_sep+"cell_history.XML")
        if not os.path.isfile(hist_name):
            shutil.copy2(self.main_directory+file_sep+"file_history.XML",homedir+file_sep+"SciPylot"+file_sep+"file_history.XML")
        if not os.path.isfile(hist_name):
            shutil.copy2(self.main_directory+file_sep+"workspace_history.XML",homedir+file_sep+"SciPylot"+file_sep+"workspace_history.XML")
        if not os.path.isfile(ext_name):
           shutil.copy2(self.main_directory+file_sep+"external_links.XML",homedir+file_sep+"SciPylot"+file_sep+"external_links.XML")

##      Set up the command histories
        try:
            the_history=[]
            parse(hist_name, GeneralXMLHandler(the_history,'history'))
            the_timestamps=[]
            parse(hist_name, GeneralXMLHandler(the_timestamps,'timestamp'))
    
            for row in xrange(len(the_history)):
                row_height = int(13*(len(the_history[row].splitlines())+.4))
                self.hist_grid.SetCellValue(row,0,the_history[row])
                self.hist_grid.SetReadOnly(row,0)
                self.hist_grid.SetCellValue(row,1,the_timestamps[row])
                self.hist_grid.SetRowSize(row,row_height)
                self.hist_grid.SetReadOnly(row,1)
                self.hist_grid.AppendRows()
                self.hist_grid.last_row+=1
            self.hist_grid.MakeCellVisible(self.hist_grid.last_row,0)
            self.shell.history=the_history
            self.shell.history.reverse()
            self.hist_grid.top_left=0
            self.hist_grid.bottom_right=1
            self.history_cell=(0,0)
            self.hist_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK,self.OnSelectHistoryCell)
            self.hist_grid.Bind(wx.grid.EVT_GRID_CELL_CHANGE,self.OnSelectHistoryCell)
    
            self.hist_grid.Bind(wx.grid.EVT_GRID_RANGE_SELECT,self.OnSelectHistoryCells)
            self.hist_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_DCLICK,self.OnLeftDClickHistory) 
            self.hist_grid.Bind(wx.grid.EVT_GRID_LABEL_RIGHT_CLICK,self.OnRClickHistory) 
    
            self.hist_grid.Bind(wx.grid.EVT_GRID_CELL_RIGHT_DCLICK,self.OnRightDClickHistory) 
            self.hist_grid.Bind(wx.EVT_KEY_DOWN,self.OnHistDelete)
        except:
            pass     
            
##      Set up the input cell history
        try:        
            the_cell_history=[]
            parse(cell_hist_name, GeneralXMLHandler(the_cell_history,'history'))
            the_timestamps=[]
            parse(cell_hist_name, GeneralXMLHandler(the_timestamps,'timestamp'))
           
            for row in xrange(len(the_cell_history)):
                row_height = int(13*(len(the_cell_history[row].splitlines())+.4))
                self.cell_hist_grid.SetCellValue(row,0,the_cell_history[row])
                self.cell_hist_grid.SetReadOnly(row,0)
                self.cell_hist_grid.SetCellValue(row,1,the_timestamps[row])
                self.cell_hist_grid.SetRowSize(row,row_height)
                self.cell_hist_grid.SetReadOnly(row,1)
                self.cell_hist_grid.AppendRows()
                self.cell_hist_grid.last_row+=1
            self.cell_hist_grid.MakeCellVisible(self.cell_hist_grid.last_row,0)
    
            self.cell_hist_grid.Bind(wx.grid.EVT_GRID_CELL_RIGHT_DCLICK,self.OnInsertInputCellHistory) 
            self.cell_hist_grid.Bind(wx.EVT_KEY_DOWN,self.OnDeleteInputCellHistory) 
        except:
            pass    
    
        try:
    ##      Set up the file history
            the_file_history=[]
            parse(file_hist_name, GeneralXMLHandler(the_file_history,'history'))
            the_timestamps=[]
            parse(file_hist_name, GeneralXMLHandler(the_timestamps,'timestamp'))
    
            for row in xrange(len(the_file_history)):
                row_height = int(13*(len(the_file_history[row].splitlines())+.4))
                self.file_hist_grid.SetCellValue(row,0,the_file_history[row])
                self.file_hist_grid.SetReadOnly(row,0)
                self.file_hist_grid.SetCellValue(row,1,the_timestamps[row])
                self.file_hist_grid.SetRowSize(row,row_height)
                self.file_hist_grid.SetReadOnly(row,1)
                self.file_hist_grid.AppendRows()
                self.file_hist_grid.last_row+=1
            self.file_hist_grid.MakeCellVisible(self.file_hist_grid.last_row,0)
            self.file_hist_grid.Bind(wx.grid.EVT_GRID_CELL_RIGHT_DCLICK,self.OnOpenFileHistory) 
            self.file_hist_grid.Bind(wx.EVT_KEY_DOWN,self.OnDeleteFileHistory) 
        except:
            pass
    ##      Set up the workspace history
        try:
            the_workspace_history=[]
            parse(workspace_hist_name, GeneralXMLHandler(the_workspace_history,'history'))
            the_timestamps=[]
            parse(workspace_hist_name, GeneralXMLHandler(the_timestamps,'timestamp'))
    
            for row in xrange(len(the_workspace_history)):
                row_height = int(13*(len(the_workspace_history[row].splitlines())+.4))
    
                self.workspace_hist_grid.SetCellValue(row,0,the_workspace_history[row])
                self.workspace_hist_grid.SetReadOnly(row,0)
                self.workspace_hist_grid.SetCellValue(row,1,the_timestamps[row])
                self.workspace_hist_grid.SetRowSize(row,row_height)
                self.workspace_hist_grid.SetReadOnly(row,1)
                self.workspace_hist_grid.AppendRows()
                self.workspace_hist_grid.last_row+=1
            self.workspace_hist_grid.MakeCellVisible(self.workspace_hist_grid.last_row,0)        
            self.workspace_hist_grid.Bind(wx.grid.EVT_GRID_CELL_RIGHT_DCLICK,self.OnOpenWorkspaceHistory) 
            self.workspace_hist_grid.Bind(wx.EVT_KEY_DOWN,self.OnDeleteWorkspaceHistory) 
        except:
            pass
        
#Create menu stuff here
        mb = wx.MenuBar()
#File Menu        
        self.printer = Printer(self)
        file_menu = wx.Menu()
        #file_menu.Append(ID_New, "New File")
        menuNew = file_menu.Append(wx.ID_NEW, "&New\tCtrl+N", "Open a new file")
        #file_menu.Append(ID_OpenFile, "Open File")
        menuOpenFile = file_menu.Append(wx.ID_OPEN, "&Open\tCtrl+O", "Open an exiting file")
        file_menu.AppendSeparator()
        #file_menu.Append(ID_Save, "Save")
        menuSave = file_menu.Append(wx.ID_SAVE, "&Save\tCtrl+S", "Save the file")
        #file_menu.Append(ID_SaveAs, "SaveAs")
        menuSaveAs = file_menu.Append(wx.ID_SAVEAS, "Save A&S\tShift+Ctrl+S", "Save As '*.py' file")
        #file_menu.Append(ID_SaveAll, "SaveAll")
        menuSaveAll = file_menu.Append(ID_SaveAll, "Save &All\tShift+Ctrl+A", "Save everything")

        file_menu.AppendSeparator()
        #file_menu.Append(ID_OpenWorkspace, "Open Workspace")
        menuOpenWorkspace = file_menu.Append(ID_OpenWorkspace, "Open &Workspace\tCtrl+W", "Open Workspace")
        #file_menu.Append(ID_SaveWorkspace, "Save Workspace")
        menuSaveWorkspace = file_menu.Append(ID_SaveWorkspace, "Save &Workspace\tShift+Ctrl+W", "Save Workspace")
        file_menu.AppendSeparator()       
        file_menu.Append(ID_PrintInputFile, "Print Input File")
        #menuPrint = file_menu.Append(ID_PrintInputFile, "PrintInputFile", "Print")
#        file_menu.Append(ID_PrintOutputFile, "Print")
        menuPrintOutputFile = file_menu.Append(ID_PrintOutputFile, "&Print Output File\tCtrl+P", "Print")
#        file_menu.AppendSeparator()      
        #file_menu.Append(ID_RecentFiles, "Recent Files")
        menuRecentFiles = file_menu.Append(ID_RecentFiles, "&Recent Files\tCtrl+R", "Recent Files")
        file_menu.AppendSeparator() 
        #file_menu.Append(wx.ID_EXIT, "Exit")
        menuExit = file_menu.Append(wx.ID_EXIT, "Exit\tCtrl+Q", "Exit SciPylot")
        

#Edit Menu
        edit_menu = wx.Menu()
        edit_menu.Append(ID_Undo, "&Undo\tCtrl+Z")
        edit_menu.Append(ID_Redo, "&Redo\tCtrl+Shift+Z")
        edit_menu.AppendSeparator()
        edit_menu.Append(ID_Copy, "&Copy\tCtrl+C")
        edit_menu.Append(ID_Paste, "&Paste\tCtrl+V")
        edit_menu.Append(ID_SelectAll, "Select &All\tCtrl+A")
        edit_menu.AppendSeparator()        
        edit_menu.Append(ID_SelectRectangle,"Select Rectangular")        
        edit_menu.Append(ID_PasteRectangle,"Paste Rectangular")


        edit_menu.AppendSeparator()
        edit_menu.Append(ID_Indent, "&Indent\tCtrl+I")
        edit_menu.Append(ID_Dedent, "&Dedent\tCtrl+D")
        #edit_menu.Append(ID_Comment, "Comment")
        menuComment = edit_menu.Append(ID_Comment, "&Comment\tCtrl+Shift+C", "")
        edit_menu.Append(ID_Uncomment, "&Uncomment\tCtrl+U")
        edit_menu.AppendSeparator()
        edit_menu.Append(ID_Find, "&Find\tCtrl+F")
#        edit_menu.Append(ID_FindAgain, "Find Again")
#        edit_menu.Append(ID_Replace, "Replace")


#Tools Menu
        tools_menu = wx.Menu()
        tools_menu.Append(ID_RunInShell, "Run File In Shell\tF5")
        tools_menu.Append(ID_RunExternally, "Run Externally")
#        tools_menu.Append(ID_ImportInShell, "Import In Shell")
        tools_menu.Append(ID_Debug, "Debug")
#        tools_menu.Append(ID_Profile, "Profile")
 

#Edit_View Menu
        edit_view_menu = wx.Menu()
#        edit_view_menu.Append(ID_Whitespace, "Whitespace")
#        edit_view_menu.Append(ID_IndentationGuides, "Indentation Guides")
#        edit_view_menu.Append(ID_RightEdgeIndicator, "Right Edge Indicator")
#        edit_view_menu.Append(ID_EndOfLineMarker, "End Of Line Marker")
#        edit_view_menu.AppendSeparator()
        edit_view_menu.Append(ID_EditPane, "Show Edit Pane","Show/Hide Edit Pane", wx.ITEM_CHECK)
        edit_view_menu.Append(ID_ControlPane, "Show Control Pane","Show/Hide Control Pane",wx.ITEM_CHECK)
        edit_view_menu.Append(ID_HelpPane, "Show Help Pane","Show/Hide Help Pane",wx.ITEM_CHECK)                
#        edit_view_menu.Append(ID_FigurePane, "Show Figure Pane","Show/Hide Figure Pane",wx.ITEM_CHECK)
        edit_view_menu.Check(ID_EditPane,check=True)
        edit_view_menu.Check(ID_ControlPane,check=True)
        edit_view_menu.Check(ID_HelpPane,check=True)

        edit_view_menu.AppendSeparator()   
        edit_view_menu.Append(ID_ZoomIn, "Zoom In")
        edit_view_menu.Append(ID_ZoomOut, "Zoom Out")
        edit_view_menu.Append(ID_ZoomFactor, "Zoom Factor")
        
        more_tools_menu=wx.Menu()
        more_tools_menu.Append(ID_ResetNamespace,"Reset Namespace")
        more_tools_menu.Append(ID_ClearShell,"Clear Shell")
        more_tools_menu.AppendSeparator() 
        more_tools_menu.Append(ID_pySketch, "Launch PySketch","Light Duty Sketching")
        more_tools_menu.AppendSeparator() 

        more_tools_menu.Append(ID_OnEmbed2DFigure, "Embed 2D Figure","Hacky Embed of 2D frame")
        more_tools_menu.Append(ID_OnClick3DtoNotebookOn, "Embed 3D Figure","Embed a 3D Canvas")





###Aui_View Menu that will be deleted soon
##        view_menu = wx.Menu()
##        view_menu.Append(ID_CreateText, "Create Text Control")
##        view_menu.Append(ID_CreateHTML, "Create HTML Control")
##        view_menu.Append(ID_CreateTree, "Create Tree")
##        view_menu.Append(ID_CreateGrid, "Create Grid")
##        view_menu.Append(ID_CreateSizeReport, "Create Size Reporter")
##        view_menu.AppendSeparator()
##        view_menu.Append(ID_GridContent, "Use a Grid for the Content Pane")
##        view_menu.Append(ID_TextContent, "Use a Text Control for the Content Pane")
##        view_menu.Append(ID_HTMLContent, "Use an HTML Control for the Content Pane")
##        view_menu.Append(ID_TreeContent, "Use a Tree Control for the Content Pane")
##        view_menu.Append(ID_SizeReportContent, "Use a Size Reporter for the Content Pane")    
        self._perspectives_menu = wx.Menu()
        self._perspectives_menu.Append(ID_CreatePerspective, "Create Perspective")
        self._perspectives_menu.Append(ID_CopyPerspective, "Copy Perspective Data To Clipboard")
        self._perspectives_menu.AppendSeparator()
        self._perspectives_menu.Append(ID_FirstPerspective+0, "Default Startup")
        self._perspectives_menu.Append(ID_FirstPerspective+1, "All Panes")
        self._perspectives_menu.Append(ID_FirstPerspective+2, "Vertical Toolbar")
           
#Pane Settings Menu
        options_menu = wx.Menu()
        options_menu.AppendMenu(wx.NewId(), "Perspectives",self._perspectives_menu)
        options_menu.AppendRadioItem(ID_TransparentHint, "Transparent Hint")
        options_menu.AppendRadioItem(ID_VenetianBlindsHint, "Venetian Blinds Hint")
        options_menu.AppendRadioItem(ID_RectangleHint, "Rectangle Hint")
        options_menu.AppendRadioItem(ID_NoHint, "No Hint")
        options_menu.AppendSeparator();
        options_menu.AppendCheckItem(ID_HintFade, "Hint Fade-in")
        options_menu.AppendCheckItem(ID_AllowFloating, "Allow Floating")
        options_menu.AppendCheckItem(ID_NoVenetianFade, "Disable Venetian Blinds Hint Fade-in")
        options_menu.AppendCheckItem(ID_TransparentDrag, "Transparent Drag")
        options_menu.AppendCheckItem(ID_AllowActivePane, "Allow Active Pane")
        options_menu.AppendSeparator();
        options_menu.AppendRadioItem(ID_NoGradient, "No Caption Gradient")
        options_menu.AppendRadioItem(ID_VerticalGradient, "Vertical Caption Gradient")
        options_menu.AppendRadioItem(ID_HorizontalGradient, "Horizontal Caption Gradient")
        options_menu.AppendSeparator();
        options_menu.Append(ID_Settings, "Settings Pane")

#Window Layout window, some to be moved, others to be deleted later
        ext_help_hist_name=homedir+file_sep+"SciPylot"+file_sep+"external_links.XML"#self.main_directory+file_sep+'external_links_test.xml'

        web_help_menu = wx.Menu()
        the_help_menu_names=[]
        parse(ext_help_hist_name, GeneralXMLHandler(the_help_menu_names,'helpmenu'))
        the_help_labels=[]
        parse(ext_help_hist_name, GeneralXMLHandler(the_help_labels,'tablabel'))
        the_help_addresses=[]
        parse(ext_help_hist_name, GeneralXMLHandler(the_help_addresses,'helplink'))
        self.help_dict={}
        for k in range(len(the_help_menu_names)):
            id=wx.NewId()
            web_help_menu.Append(id,the_help_menu_names[k])
            self.help_dict[id]=(the_help_labels[k],the_help_addresses[k])
            self.Bind(wx.EVT_MENU, self.OnExternalHelp, id=id)            

        
                   
        help_menu = wx.Menu()
        help_menu.Append(ID_HelpEnv, "SciPylot Help")
        help_menu.Append(ID_LocalHelp, "Local Titles")
        help_menu.AppendMenu(ID_WebHelp, "Web Titles",web_help_menu)
        help_menu.AppendSeparator()        
        help_menu.Append(ID_About, "About SciPylot")
        
        
        mb.Append(file_menu, "File")
        mb.Append(edit_menu, "Edit")
        mb.Append(edit_view_menu, "View")       
        mb.Append(tools_menu, "Run") 
#        mb.Append(view_menu, "AuiView")
#        mb.Append(self._perspectives_menu, "Perspectives")
        mb.Append(more_tools_menu, 'Tools')
        mb.Append(options_menu, "Layout")
        mb.Append(help_menu, "Help")
        self.menubar=mb
        self.SetMenuBar(mb)

        self.statusbar = self.CreateStatusBar(2, wx.ST_SIZEGRIP)
        self.statusbar.SetStatusWidths([-2, -3])
        self.statusbar.SetStatusText("Ready", 0)
        self.statusbar.SetStatusText("Welcome To wxPython!", 1)

        # min size for the frame itself isn't completely done.
        # see the end up FrameManager::Update() for the test
        # code. For now, just hard code a frame minimum size
        
        self.SetMinSize(wx.Size(400, 300))


        # create some toolbars
        tsize = (22,22)
        
        sptb = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
                         wx.TB_FLAT | wx.TB_NODIVIDER)
        sptb.SetToolBitmapSize(tsize)
        sptb_New_bmp = wx.ArtProvider.GetBitmap(wx.ART_NEW, wx.ART_TOOLBAR, tsize)       
        sptb.AddLabelTool(ID_New_TB, "New File Panel", sptb_New_bmp, shortHelp="New File Panel")
        sptb_OpenFile_bmp = wx.ArtProvider.GetBitmap(wx.ART_FILE_OPEN, wx.ART_TOOLBAR, tsize)       
        sptb.AddLabelTool(ID_OpenFile_TB, "Open File", sptb_OpenFile_bmp, shortHelp="Open File")
        sptb_Save_bmp = wx.ArtProvider_GetBitmap(wx.ART_FILE_SAVE, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Save_TB, "Save Current Panel", sptb_Save_bmp, shortHelp="Save Current Panel")
        sptb_Print_bmp = wx.ArtProvider_GetBitmap(wx.ART_PRINT, wx.ART_OTHER, tsize)        
#        sptb.AddLabelTool(ID_Print_TB, "Print Current Panel", sptb_Print_bmp, shortHelp="Print Current Panel")
        sptb.AddSeparator()
        sptb_Undo_bmp = wx.ArtProvider_GetBitmap(wx.ART_UNDO, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Undo_TB, "Undo", sptb_Undo_bmp, shortHelp="Undo")
        sptb_Redo_bmp = wx.ArtProvider_GetBitmap(wx.ART_REDO, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Redo_TB, "Redo", sptb_Redo_bmp, shortHelp="Redo")
        sptb_Copy_bmp = wx.ArtProvider.GetBitmap(wx.ART_COPY, wx.ART_TOOLBAR, tsize)       
        sptb.AddLabelTool(ID_Copy_TB, "Copy", sptb_Copy_bmp, shortHelp="Copy")
        sptb_Cut_bmp = wx.ArtProvider.GetBitmap(wx.ART_CUT, wx.ART_TOOLBAR, tsize)       
        sptb.AddLabelTool(ID_Cut_TB, "Cut", sptb_Cut_bmp, shortHelp="Cut")

        sptb_Paste_bmp = wx.ArtProvider.GetBitmap(wx.ART_PASTE, wx.ART_TOOLBAR, tsize)       
        sptb.AddLabelTool(ID_Paste_TB, "Paste", sptb_Paste_bmp,shortHelp="Paste")

        image=wx.Image('indent.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_Indent_bmp=image.ConvertToBitmap()

#        sptb_Indent_bmp = wx.Bitmap('indent.png')#wx.ArtProvider_GetBitmap(wx.ART_QUESTION, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Indent_TB, "Indent", sptb_Indent_bmp, shortHelp="Indent Selected Lines")

        image=wx.Image('unindent.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_Dedent_bmp=image.ConvertToBitmap()

#        sptb_Dedent_bmp = wx.Bitmap('unindent.png')#wx.ArtProvider_GetBitmap(wx.ART_QUESTION, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Dedent_TB, "Unindent", sptb_Dedent_bmp,shortHelp="Unindent Selected Lines")

        image=wx.Image('comment.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_Comment_bmp=image.ConvertToBitmap()

#        sptb_Comment_bmp = wx.Bitmap('comment.png')#wx.ArtProvider_GetBitmap(wx.ART_QUESTION, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Comment_TB, "Comment Selection", sptb_Comment_bmp,shortHelp= "Comment Selected Lines")

        image=wx.Image('uncomment.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_Uncomment_bmp=image.ConvertToBitmap()

#        sptb_Uncomment_bmp = wx.Bitmap('uncomment.png')#wx.ArtProvider_GetBitmap(wx.ART_QUESTION, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Uncomment_TB, "Uncommment Selection", sptb_Uncomment_bmp, shortHelp="Uncommment Selected Lines")

        sptb_Find_bmp = wx.ArtProvider_GetBitmap(wx.ART_FIND, wx.ART_OTHER, tsize)        
        sptb.AddLabelTool(ID_Find_TB, "Find in Current Panel", sptb_Find_bmp, shortHelp="Find in Current Panel")
#        sptb_Replace_bmp = wx.ArtProvider_GetBitmap(wx.ART_FIND_AND_REPLACE, wx.ART_OTHER, tsize)        
#        sptb.AddLabelTool(ID_Replace_TB, "Replace",sptb_Replace_bmp, shortHelp="Replace")
        sptb.AddSeparator()

        image=wx.Image('zoomin.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_ZoomIn_bmp=image.ConvertToBitmap()

#        sptb_ZoomIn_bmp = wx.Bitmap('zoomin.png')
        sptb.AddLabelTool(ID_ZoomIn_TB, "Find in Current Panel", sptb_ZoomIn_bmp, shortHelp="Zoom In")
        image=wx.Image('zoomout.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_ZoomOut_bmp=image.ConvertToBitmap()


#        sptb_ZoomOut_bmp = wx.Bitmap('zoomout.png')
        sptb.AddLabelTool(ID_ZoomOut_TB, "Find in Current Panel", sptb_ZoomOut_bmp, shortHelp="Zoom Out")
#        sptb.AddSeparator()
        sptb_restore_bmp = wx.Bitmap('view_choose.png')
#        sptb.AddLabelTool(ID_RestoreView_TB, "Restore View", sptb_restore_bmp, shortHelp="Restore Previos Layout")
       

        sptb.Realize()
        
        sptb_tools = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
                         wx.TB_FLAT | wx.TB_NODIVIDER)
        sptb_tools.SetToolBitmapSize(tsize)
        image=wx.Image('debug.png', type=wx.BITMAP_TYPE_PNG)
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        image.Rescale(tsize[0],tsize[1])
        sptb_RunInShell_bmp=image.ConvertToBitmap()
#        sptb_RunInShell_bmp = wx.Bitmap('debug.png')#wx.ArtProvider_GetBitmap(wx.ART_EXECUTABLE_FILE, wx.ART_OTHER, tsize)        
        sptb_tools.AddLabelTool(ID_RunInShell, "Run in Shell", sptb_RunInShell_bmp, shortHelp="Run in Shell")

        image=wx.Image('gear.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_RunExternally_bmp=image.ConvertToBitmap()

#        sptb_RunExternally_bmp = wx.Bitmap('gear.png')#wx.ArtProvider_GetBitmap(wx.ART_GO_DOWN, wx.ART_OTHER, tsize)        
        sptb_tools.AddLabelTool(ID_RunExternally_TB, "Run in External Interpreter", sptb_RunExternally_bmp, shortHelp="Run in External Interpreter")
        sptb_ImportInShell_bmp = wx.ArtProvider_GetBitmap(wx.ART_GO_TO_PARENT, wx.ART_OTHER, tsize)
#        sptb_tools.AddLabelTool(ID_ImportInShell_TB, "Import to Shell", sptb_ImportInShell_bmp, shortHelp="Import to Shell")
        sptb_Debug_bmp = wx.ArtProvider_GetBitmap(wx.ART_EXECUTABLE_FILE, wx.ART_OTHER, tsize)#wx.Bitmap('debug.png')#wx.ArtProvider_GetBitmap(wx.ART_GO_HOME, wx.ART_OTHER, tsize)          
        sptb_tools.AddLabelTool(ID_Debug_TB, "Debug", sptb_Debug_bmp, shortHelp="Debug")
#        sptb_tools.AddSeparator()
        sptb_Help_bmp = wx.ArtProvider_GetBitmap(wx.ART_QUESTION, wx.ART_OTHER, tsize)
#        sptb_tools.AddLabelTool(ID_Help_TB, "Help", sptb_Help_bmp, shortHelp="Help")
        sptb_tools.Realize()

        sptb_2D = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
                         wx.TB_FLAT | wx.TB_NODIVIDER)
        sptb_2D.SetToolBitmapSize(tsize)
        image=wx.Image('folder_image.png', type=wx.BITMAP_TYPE_PNG)
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        image.Rescale(tsize[0],tsize[1])
        sptb_insert2D_bmp=image.ConvertToBitmap()
#        sptb_insert2D_bmp = wx.Bitmap(image)#wx.ArtProvider_GetBitmap(wx.ART_GO_DOWN, wx.ART_OTHER, tsize)
        sptb_2D.AddLabelTool(ID_insert2D_TB, "Embed 2D Figure Window", sptb_insert2D_bmp, shortHelp="Embed 2D Window")
        
        image=wx.Image('editcopy.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        #image.Rescale(tsize[0],tsize[1])
        sptb_copy2D_bmp=image.ConvertToBitmap()

#        sptb_copy2D_bmp = wx.Bitmap(image)#wx.ArtProvider_GetBitmap(wx.ART_GO_HOME, wx.ART_OTHER, tsize)          
        sptb_2D.AddLabelTool(ID_copy2D_TB, "Copy 2D Figure to Clipboard", sptb_copy2D_bmp, shortHelp="Copy 2D to Clipboard")
        image=wx.Image('folder_green.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
        sptb_clear2D_bmp=image.ConvertToBitmap()
        sptb_2D.AddLabelTool(ID_clear2D_TB, "Clear Current 2D Figure", sptb_clear2D_bmp, shortHelp="Clear 2D Figure")
        
##        sptb_2D.AddSeparator()
##        sptb_Help_bmp = wx.Bitmap('edit_add.png')        
##        sptb_2D.AddLabelTool(ID_Help_TB, "Help", sptb_Help_bmp, shortHelp="Help")
        sptb_2D.Realize()


        sptb_3D = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
                         wx.TB_FLAT | wx.TB_NODIVIDER)
        sptb_3D.SetToolBitmapSize(tsize)
        image=wx.Image('folder_html.png', type=wx.BITMAP_TYPE_PNG)
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        image.Rescale(tsize[0],tsize[1])
        sptb_insert3D_bmp=image.ConvertToBitmap()
#        sptb_insert3D_bmp = wx.Bitmap('fileimport.png')#wx.ArtProvider_GetBitmap(wx.ART_GO_DOWN, wx.ART_OTHER, tsize)        
        sptb_3D.AddLabelTool(ID_insert3D_TB, "Embed 3D Figure Window", sptb_insert3D_bmp, shortHelp="Embed 3D Figure Window")
        image=wx.Image('kcmkwm.png', type=wx.BITMAP_TYPE_PNG)
#        im2=wx.EmptyBitmap(tsize[0],tsize[1])
        image.Rescale(tsize[0],tsize[1])
        sptb_copy3D_bmp = image.ConvertToBitmap()#wx.ArtProvider_GetBitmap(wx.ART_GO_HOME, wx.ART_OTHER, tsize)          
        sptb_3D.AddLabelTool(ID_copy3D_TB, "Copy 3D Figure to Clipboard", sptb_copy3D_bmp, shortHelp="Copy 3D to Clipboard")
        image=wx.Image('folder_red.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
        sptb_clear3D_bmp=image.ConvertToBitmap()
        sptb_3D.AddLabelTool(ID_clear3D_TB, "Clear Current 3D Figure", sptb_clear3D_bmp, shortHelp="Clear 3D Figure")
#        sptb_3D.AddSeparator()
 
        image=wx.Image('mayavi2-48x48.png', type=wx.BITMAP_TYPE_PNG)
        image.Rescale(tsize[0],tsize[1])
        sptb_pipeline3D_bmp=image.ConvertToBitmap()
        sptb_3D.AddLabelTool(ID_openPipeline_TB, "Open 3D Pipeline Viewer", sptb_pipeline3D_bmp, shortHelp="Open 3D Pipeline")

##        sptb_2D.AddSeparator()
##        sptb_Help_bmp = wx.Bitmap('edit_add.png')        
##        sptb_2D.AddLabelTool(ID_Help_TB, "Help", sptb_Help_bmp, shortHelp="Help")
        sptb_3D.Realize()

        # create some toolbars
##        tb1 = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
##                         wx.TB_FLAT | wx.TB_NODIVIDER)
##        tb1.SetToolBitmapSize(wx.Size(48,48))
##        tb1.AddLabelTool(101, "Test", wx.ArtProvider_GetBitmap(wx.ART_ERROR))
##        tb1.AddSeparator()
##        tb1.AddLabelTool(102, "Test", wx.ArtProvider_GetBitmap(wx.ART_QUESTION))
##        tb1.AddLabelTool(103, "Test", wx.ArtProvider_GetBitmap(wx.ART_INFORMATION))
##        tb1.AddLabelTool(103, "Test", wx.ArtProvider_GetBitmap(wx.ART_WARNING))
##        tb1.AddLabelTool(103, "Test", wx.ArtProvider_GetBitmap(wx.ART_MISSING_IMAGE))
##        tb1.Realize()
##
##        tb2 = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
##                         wx.TB_FLAT | wx.TB_NODIVIDER)
##        tb2.SetToolBitmapSize(wx.Size(16,16))
##        tb2_bmp1 = wx.ArtProvider_GetBitmap(wx.ART_QUESTION, wx.ART_OTHER, wx.Size(16, 16))
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddSeparator()
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddSeparator()
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.AddLabelTool(101, "Test", tb2_bmp1)
##        tb2.Realize()
##       
##        tb3 = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
##                         wx.TB_FLAT | wx.TB_NODIVIDER)
##        tb3.SetToolBitmapSize(wx.Size(16,16))
##        tb3_bmp1 = wx.ArtProvider_GetBitmap(wx.ART_FOLDER, wx.ART_OTHER, wx.Size(16, 16))
##        tb3.AddLabelTool(101, "Test", tb3_bmp1)
##        tb3.AddLabelTool(101, "Test", tb3_bmp1)
##        tb3.AddLabelTool(101, "Test", tb3_bmp1)
##        tb3.AddLabelTool(101, "Test", tb3_bmp1)
##        tb3.AddSeparator()
##        tb3.AddLabelTool(101, "Test", tb3_bmp1)
##        tb3.AddLabelTool(101, "Test", tb3_bmp1)
##        tb3.Realize()
##
##        tb4 = wx.ToolBar(self, -1, wx.DefaultPosition, wx.DefaultSize,
##                         wx.TB_FLAT | wx.TB_NODIVIDER | wx.TB_HORZ_TEXT)        # add a bunch of panes

#        self._mgr.AddPane(self.help_panel, wx.aui.AuiPaneInfo().
#                          Name("help").Caption("Documents and Help").Direction(4).Row(0).
#                          Layer(2).Position(0).CloseButton(True).MaximizeButton(True))


        self._mgr.AddPane(self.help_panel, wx.aui.AuiPaneInfo().
                          Name("help").Caption("Documents and Help").Left().CloseButton(True).MaximizeButton(True))
#name=help;caption=Documents and Help;state=6293500;dir=4;layer=2;row=0;pos=0;prop=100000;bestw=20;besth=20;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=327;floaty=163;floatw=33;floath=50

        self._mgr.AddPane(self.nbpanel, wx.aui.AuiPaneInfo().
                          Name("workspace").Caption("Control Pane").Bottom().CloseButton(True).MaximizeButton(True))



#        self._mgr.AddPane(self.nbpanel, wx.aui.AuiPaneInfo().
#                          Name("workspace").Caption("Control Pane").
#                          Direction(4).Layer(2).Row(0).Position(1).CloseButton(True).MaximizeButton(True))
#|name=workspace;caption=Workspace Info;state=6293500;dir=4;layer=2;row=0;pos=1;prop=100000;bestw=300;besth=300;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=21;floaty=600;floatw=308;floath=330
        self._mgr.AddPane(self.editor_panel, wx.aui.AuiPaneInfo().
                          Name("editor").Caption("Editor Pane").Top().
                          CloseButton(True).MaximizeButton(True))


#        self._mgr.AddPane(self.editor_panel, wx.aui.AuiPaneInfo().
#                          Name("editor").Caption("Editor Pane").
#                          Direction(1).Layer(0).Row(1).Position(0).CloseButton(True).MaximizeButton(True))
#|name=editor;caption=Editor Pane;state=6293500;dir=1;layer=0;row=1;pos=0;prop=100000;bestw=20;besth=20;minw=-1;minh=-1;maxw=-1;maxh=-1;floatx=334;floaty=595;floatw=33;floath=50


##        self._mgr.AddPane(SettingsPanel(self, self), wx.aui.AuiPaneInfo().
##                          Name("settings").Caption("Dock Manager Settings").
##                          Dockable(False).Float().CloseButton(True).MaximizeButton(True))

        # create some center panes


        self._mgr.AddPane(self.crustpanel, wx.aui.AuiPaneInfo().Name("crust_panel").
                          CenterPane())
                                
        # add the toolbars to the manager
                        

        self._mgr.AddPane(sptb, wx.aui.AuiPaneInfo().
                          Name("sptb").Caption("SciPylot Toolbar").
                          ToolbarPane().Top().
                          LeftDockable(False).RightDockable(False))
        self._mgr.AddPane(sptb_tools, wx.aui.AuiPaneInfo().
                          Name("sptb_tools").Caption("SciPylot Toolbar Tools").
                          ToolbarPane().Top().Row(1).Position(1).
                          LeftDockable(False).RightDockable(False))
        self._mgr.AddPane(sptb_2D, wx.aui.AuiPaneInfo().
                          Name("sptb_2D").Caption("SciPylot Toolbar 2D").
                          ToolbarPane().Top().Row(1).Position(1).
                          LeftDockable(False).RightDockable(False))
        self._mgr.AddPane(sptb_3D, wx.aui.AuiPaneInfo().
                          Name("sptb_3D").Caption("SciPylot Toolbar 3D").
                          ToolbarPane().Top().Row(1).Position(1).
                          LeftDockable(False).RightDockable(False))
                      


        # make some default perspectives


##        self._mgr.GetPane("settings").Hide()        
        perspective_all = self._mgr.SavePerspective()
        
        all_panes = self._mgr.GetAllPanes()
        
##        for ii in xrange(len(all_panes)):
##            if not all_panes[ii].IsToolbar():
##                all_panes[ii].Hide()
##                
##
##        self._mgr.GetPane("editor").Show().Left().Layer(0).Row(0).Position(0)
##
##
##        
##        self._mgr.GetPane("workspace").Show().Bottom().Layer(0).Row(0).Position(0)
##        self._mgr.GetPane("crust_panel").Show()

        perspective_default=layout

#        perspective_default = self._mgr.SavePerspective()
        self.current_layout=perspective_default

#        for ii in xrange(len(all_panes)):
#            if not all_panes[ii].IsToolbar():
#                all_panes[ii].Hide()


#        self._mgr.GetPane("tb1").Hide()
#        self._mgr.GetPane("tb5").Hide()
#        self._mgr.GetPane("tbvert").Show()
##        self._mgr.GetPane("grid_content").Show()
##        self._mgr.GetPane("test8").Show().Left().Layer(0).Row(0).Position(0)
#        self._mgr.GetPane("workspace").Show().Bottom().Layer(0).Row(0).Position(0)
#        self._mgr.GetPane("crust_panel").Show()

#        perspective_vert = self._mgr.SavePerspective()
        
        self._perspectives.append(perspective_default)
        self._perspectives.append(perspective_all)
#        self._perspectives.append(perspective_vert)

#        self._mgr.GetPane("tbvert").Hide()
##        self._mgr.GetPane("grid_content").Hide()
        self._mgr.LoadPerspective(self._perspectives[0])

        # "commit" all changes made to FrameManager
        self._mgr.Update()

        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBackground)
        self.Bind(wx.EVT_SIZE, self.OnSize)
        self.Bind(wx.EVT_CLOSE, self.OnClose)
        

        # Show How To Use The Closing Panes Event
        
# File Menu Bindings        
        #self.Bind(wx.EVT_MENU, self.OnSave, id=ID_Save)
        self.Bind(wx.EVT_MENU, self.OnSave, menuSave)
        #self.Bind(wx.EVT_MENU, self.OnNew, id=ID_New)
        self.Bind(wx.EVT_MENU, self.OnNew, menuNew)
        #self.Bind(wx.EVT_MENU, self.OnSaveAs, id=ID_SaveAs)
        self.Bind(wx.EVT_MENU, self.OnSaveAs, menuSaveAs)
        #self.Bind(wx.EVT_MENU, self.OnSaveAll, id=ID_SaveAll)
        self.Bind(wx.EVT_MENU, self.OnSaveAll, menuSaveAll)
        #self.Bind(wx.EVT_MENU, self.OnOpenFile, id=ID_OpenFile)
        self.Bind(wx.EVT_MENU, self.OnOpenFile, menuOpenFile)
        #self.Bind(wx.EVT_MENU, self.OnOpenWorkspace, id=ID_OpenWorkspace)
        self.Bind(wx.EVT_MENU, self.OnOpenWorkspace, menuOpenWorkspace)
        #self.Bind(wx.EVT_MENU, self.OnSaveWorkspace, id=ID_SaveWorkspace)
        self.Bind(wx.EVT_MENU, self.OnSaveWorkspace, menuSaveWorkspace)
        self.Bind(wx.EVT_MENU, self.OnPrintInputFile, id=ID_PrintInputFile)
        #self.Bind(wx.EVT_MENU, self.OnPrintInputFile, menuPrintInputFile)
        #self.Bind(wx.EVT_MENU, self.OnPrintOutputFile, id=ID_PrintOutputFile)
        self.Bind(wx.EVT_MENU, self.OnPrintOutputFile, menuPrintOutputFile)
        #self.Bind(wx.EVT_MENU, self.OnRecentFiles, id=ID_RecentFiles)
        self.Bind(wx.EVT_MENU, self.OnRecentFiles, menuRecentFiles)
        self.Bind(wx.EVT_MENU, self.OnExit, menuExit)

# Accelerate Table        
        self.Bind(wx.EVT_MENU, self.OnSave, id=ID_Save)
        self.Bind(wx.EVT_MENU, self.OnNew, id=ID_New)
        self.Bind(wx.EVT_MENU, self.OnSaveAs, id=ID_SaveAs)
        self.Bind(wx.EVT_MENU, self.OnSaveAll, id=ID_SaveAll)
        self.Bind(wx.EVT_MENU, self.OnOpenFile, id=ID_OpenFile)
        self.Bind(wx.EVT_MENU, self.OnOpenWorkspace, id=ID_OpenWorkspace)
        self.Bind(wx.EVT_MENU, self.OnSaveWorkspace, id=ID_SaveWorkspace)
        #self.Bind(wx.EVT_MENU, self.OnPrintInputFile, id=ID_PrintInputFile)
        self.Bind(wx.EVT_MENU, self.OnPrintOutputFile, id=ID_PrintOutputFile)
        self.Bind(wx.EVT_MENU, self.OnRecentFiles, id=ID_RecentFiles)
        self.Bind(wx.EVT_MENU, self.OnExit, id=ID_Exit)
        self.accel_tbl_1 = wx.AcceleratorTable([(wx.ACCEL_CTRL, ord('S'), ID_Save),
                                              (wx.ACCEL_CTRL, ord('N'), ID_New),
                                              (wx.ACCEL_SHIFT|wx.ACCEL_CTRL, ord('S'), ID_SaveAs),
                                              (wx.ACCEL_SHIFT|wx.ACCEL_CTRL, ord('A'), ID_SaveAll),
                                              (wx.ACCEL_CTRL, ord('O'), ID_OpenFile),
                                              (wx.ACCEL_CTRL, ord('W'), ID_OpenWorkspace),
                                              (wx.ACCEL_SHIFT|wx.ACCEL_CTRL, ord('W'), ID_SaveWorkspace),
                                              #(wx.ACCEL_CTRL, ord('P'), ID_PrintInputFile),
                                              (wx.ACCEL_CTRL, ord('P'), ID_PrintOutputFile),
                                              (wx.ACCEL_CTRL, ord('R'), ID_RecentFiles),
                                              (wx.ACCEL_CTRL, ord('Q'), ID_Exit)])
        self.SetAcceleratorTable(self.accel_tbl_1)
        
#Edit Menu Bindings
        self.Bind(wx.EVT_MENU, self.OnUndo, id=ID_Undo)
        self.Bind(wx.EVT_MENU, self.OnRedo, id=ID_Redo)
        self.Bind(wx.EVT_MENU, self.OnCopy, id=ID_Copy)
        self.Bind(wx.EVT_MENU, self.OnCut, id=ID_Cut)
        self.Bind(wx.EVT_MENU, self.OnPasteRectangle, id=ID_PasteRectangle)
        self.Bind(wx.EVT_MENU, self.OnSelectRectangle, id=ID_SelectRectangle)

        self.Bind(wx.EVT_MENU, self.OnPaste, id=ID_Paste)
        self.Bind(wx.EVT_MENU, self.OnSelectAll, id=ID_SelectAll)
        self.Bind(wx.EVT_MENU, self.OnIndent, id=ID_Indent)
        self.Bind(wx.EVT_MENU, self.OnDedent, id=ID_Dedent)
        
        #self.Bind(wx.EVT_MENU, self.OnComment, id=ID_Comment)
        self.Bind(wx.EVT_MENU, self.OnComment, menuComment)
 # Accelerate Table 
        self.Bind(wx.EVT_MENU, self.OnComment, id=ID_Comment)       
        self.accel_tbl_2 = wx.AcceleratorTable([(wx.ACCEL_CTRL|wx.ACCEL_SHIFT, ord('C'), ID_Comment)])
        self.SetAcceleratorTable(self.accel_tbl_2)
        
        
        self.Bind(wx.EVT_MENU, self.OnUncomment, id=ID_Uncomment)
        self.Bind(wx.EVT_MENU, self.OnFind, id=ID_Find)
#        self.Bind(wx.EVT_MENU, self.OnFindAgain, id=ID_FindAgain)
        self.Bind(wx.EVT_MENU, self.OnReplace, id=ID_Replace)
        
        
        self.Bind(wx.EVT_MENU, self.OnViewPane, id=ID_EditPane)
        self.Bind(wx.EVT_MENU, self.OnViewPane, id=ID_ControlPane)
        self.Bind(wx.EVT_MENU, self.OnViewPane, id=ID_HelpPane)
#        self.Bind(wx.EVT_MENU, self.OnViewPane, id=ID_FigurePane)        
        self.Bind(wx.EVT_MENU, self.OnZoomIn, id=ID_ZoomIn)
        self.Bind(wx.EVT_MENU, self.OnZoomOut, id=ID_ZoomOut)
        self.Bind(wx.EVT_MENU, self.OnZoomLevel, id=ID_ZoomFactor)        

        self.Bind(wx.EVT_MENU, self.OnResetNamespace, id=ID_ResetNamespace)       
        self.Bind(wx.EVT_MENU, self.OnClearShell, id=ID_ClearShell)       
        self.Bind(wx.EVT_MENU, self.OnpySketch, id=ID_pySketch)       
        self.Bind(wx.EVT_MENU, self.OnEmbed2DFigure, id=ID_OnEmbed2DFigure)       
        self.Bind(wx.EVT_MENU, self.OnClick3DtoNotebookOn, id=ID_OnClick3DtoNotebookOn)       


        
        
#Special Find/Replace Bindings        
        self.Bind(wx.EVT_FIND, self.OnFindSet)
        self.Bind(wx.EVT_FIND_NEXT, self.OnFindSet)
        self.Bind(wx.EVT_FIND_REPLACE, self.OnFindSet)
        self.Bind(wx.EVT_FIND_REPLACE_ALL, self.OnFindSet)
        self.Bind(wx.EVT_FIND_CLOSE, self.OnFindClose)
        self.FindActive=False#Set this to monitor whether or not the dialog is open
        self.activepage=None#for keeping track of changes in files during searches        

        
#Tools Menu Bindings
        self.Bind(wx.EVT_MENU, self.OnRunInShell, id=ID_RunInShell)
        self.Bind(wx.EVT_MENU, self.OnRunExternally, id=ID_RunExternally)
#        self.Bind(wx.EVT_MENU, self.OnImportInShell, id=ID_ImportInShell)
        self.Bind(wx.EVT_MENU, self.OnDebug, id=ID_Debug)
#        self.Bind(wx.EVT_MENU, self.OnProfile, id=ID_Profile)

# File Tool Bindings        
        self.Bind(wx.EVT_TOOL, self.OnSave, id=ID_Save_TB)
        self.Bind(wx.EVT_TOOL, self.OnNew, id=ID_New_TB)
##        self.Bind(wx.EVT_TOOL, self.OnSaveAs, id=ID_SaveAs_TB)
        self.Bind(wx.EVT_TOOL, self.OnOpenFile, id=ID_OpenFile_TB)
#        self.Bind(wx.EVT_TOOL, self.OnPrint, id=ID_Print_TB)
#Edit Tool Bindings
        self.Bind(wx.EVT_TOOL, self.OnUndo, id=ID_Undo_TB)
        self.Bind(wx.EVT_TOOL, self.OnRedo, id=ID_Redo_TB)
        self.Bind(wx.EVT_TOOL, self.OnCopy, id=ID_Copy_TB)
        self.Bind(wx.EVT_TOOL, self.OnCut, id=ID_Cut_TB)     
        self.Bind(wx.EVT_TOOL, self.OnPaste, id=ID_Paste_TB)



#        self.Bind(wx.EVT_TOOL, self.OnSelectAll, id=ID_SelectAll_TB)
        self.Bind(wx.EVT_TOOL, self.OnIndent, id=ID_Indent_TB)
        self.Bind(wx.EVT_TOOL, self.OnDedent, id=ID_Dedent_TB)
        self.Bind(wx.EVT_TOOL, self.OnComment, id=ID_Comment_TB)
        self.Bind(wx.EVT_TOOL, self.OnUncomment, id=ID_Uncomment_TB)
        self.Bind(wx.EVT_TOOL, self.OnFind, id=ID_Find_TB)
##        self.Bind(wx.EVT_TOOL, self.OnFindAgain, id=ID_FindAgain_TB)
##        self.Bind(wx.EVT_TOOL, self.OnReplace, id=ID_Replace_TB)
#Tools Tool Bindings
        self.Bind(wx.EVT_TOOL, self.OnRunInShell, id=ID_RunInShell_TB)
        self.Bind(wx.EVT_TOOL, self.OnRunExternally, id=ID_RunExternally_TB)
#        self.Bind(wx.EVT_TOOL, self.OnImportInShell, id=ID_ImportInShell_TB)
        self.Bind(wx.EVT_TOOL, self.OnDebug, id=ID_Debug_TB)
#        self.Bind(wx.EVT_TOOL, self.OnProfile, id=ID_Profile)

#        self.Bind(wx.EVT_TOOL, self.OnRestoreLastPerspective, id=ID_RestoreView_TB)
#        self.Bind(wx.EVT_TOOL, self.OnClickHelp, id=ID_Help_TB)


        self.Bind(wx.EVT_TOOL, self.OnEmbed2DFigure, id=ID_insert2D_TB)
        self.Bind(wx.EVT_TOOL, self.OnClick3DtoNotebookOn, id=ID_insert3D_TB)
        self.Bind(wx.EVT_TOOL, self.OnCopy2D, id=ID_copy2D_TB)
        self.Bind(wx.EVT_TOOL, self.OnClear2D, id=ID_clear2D_TB)
        self.Bind(wx.EVT_TOOL, self.OnClear3D, id=ID_clear3D_TB)
        self.Bind(wx.EVT_TOOL, self.OnCopy3D, id=ID_copy3D_TB)
        self.Bind(wx.EVT_TOOL, self.OnOpenPipeline, id=ID_openPipeline_TB)
        

#View Menu Bindings
##ID_Whitespace=wx.NewId()
##ID_IndentationGuides=wx.NewId()
##ID_RightEdgeIndicator=wx.NewId()
##ID_EndOfLineMarker=wx.NewId()
##ID_ZoomFactor=wx.NewId()


#View Tool Bindings
##ID_Whitespace=wx.NewId()
##ID_IndentationGuides=wx.NewId()
##ID_RightEdgeIndicator=wx.NewId()
##ID_EndOfLineMarker=wx.NewId()
##ID_ZoomFactor=wx.NewId()
        self.Bind(wx.EVT_TOOL, self.OnZoomIn, id=ID_ZoomIn_TB)
        self.Bind(wx.EVT_TOOL, self.OnZoomOut, id=ID_ZoomOut_TB)
        
##        self.Bind(wx.EVT_MENU, self.OnCreateTree, id=ID_CreateTree)        
##        self.Bind(wx.EVT_MENU, self.OnCreateTree, id=ID_CreateTree)
##        self.Bind(wx.EVT_MENU, self.OnCreateGrid, id=ID_CreateGrid)
##        self.Bind(wx.EVT_MENU, self.OnCreateText, id=ID_CreateText)
##        self.Bind(wx.EVT_MENU, self.OnCreateHTML, id=ID_CreateHTML)
##        self.Bind(wx.EVT_MENU, self.OnCreateSizeReport, id=ID_CreateSizeReport)
##        self.Bind(wx.EVT_MENU, self.OnCreatePerspective, id=ID_CreatePerspective)
##        self.Bind(wx.EVT_MENU, self.OnCopyPerspective, id=ID_CopyPerspective)

        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_AllowFloating)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_TransparentHint)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_VenetianBlindsHint)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_RectangleHint)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_NoHint)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_HintFade)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_NoVenetianFade)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_TransparentDrag)
        self.Bind(wx.EVT_MENU, self.OnManagerFlag, id=ID_AllowActivePane)
        
        self.Bind(wx.EVT_MENU, self.OnGradient, id=ID_NoGradient)
        self.Bind(wx.EVT_MENU, self.OnGradient, id=ID_VerticalGradient)
        self.Bind(wx.EVT_MENU, self.OnGradient, id=ID_HorizontalGradient)
        self.Bind(wx.EVT_MENU, self.OnSettings, id=ID_Settings)
        self.Bind(wx.EVT_MENU, self.OnChangeContentPane, id=ID_GridContent)
        self.Bind(wx.EVT_MENU, self.OnChangeContentPane, id=ID_TreeContent)
        self.Bind(wx.EVT_MENU, self.OnChangeContentPane, id=ID_TextContent)
        self.Bind(wx.EVT_MENU, self.OnChangeContentPane, id=ID_SizeReportContent)
        self.Bind(wx.EVT_MENU, self.OnChangeContentPane, id=ID_HTMLContent)
        self.Bind(wx.EVT_MENU, self.OnExit, id=wx.ID_EXIT)
        self.Bind(wx.EVT_MENU, self.OnAbout, id=ID_About)

        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_TransparentHint)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_VenetianBlindsHint)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_RectangleHint)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_NoHint)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_HintFade)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_AllowFloating)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_NoVenetianFade)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_TransparentDrag)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_AllowActivePane)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_NoGradient)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_VerticalGradient)
        self.Bind(wx.EVT_UPDATE_UI, self.OnUpdateUI, id=ID_HorizontalGradient)

    
        self.Bind(wx.EVT_MENU_RANGE, self.OnRestorePerspective, id=ID_FirstPerspective,
                  id2=ID_FirstPerspective+3)
        self.notebook1.Bind(wx.aui.EVT_AUINOTEBOOK_PAGE_CLOSE, self.OnCloseNotebookPage)
        self.Bind(wx.aui.EVT_AUI_PANE_MAXIMIZE, self.OnMaximizePane)
        self.Bind(wx.aui.EVT_AUI_PANE_RESTORE, self.OnRestorePane)
#        self.Bind(wx.aui.EVT_AUI_PANE_BUTTON, self.OnRestorePane)
        self.Bind(wx.aui.EVT_AUI_PANE_CLOSE, self.OnPaneClose)
        
        self.nbeditor.Bind(wx.aui.EVT_AUINOTEBOOK_PAGE_CHANGED, self.onPageChanged)
        self.nbeditor.Bind(wx.aui.EVT_AUINOTEBOOK_PAGE_CLOSE, self.OnCloseNotebookPage)
        self.help_notebook.Bind(wx.aui.EVT_AUINOTEBOOK_PAGE_CLOSE, self.OnCloseHelpPage)
        self.help_notebook.Bind(wx.aui.EVT_AUINOTEBOOK_PAGE_CHANGED, self.OnGraphSize)
#        self.help_panel.Bind(wx.EVT_SIZE,self.OnGraphSize)         
#        self.notebook1.Bind(wx.EVT_CLOSE, self.OnCloseNotebookPage)

#        print self._perspectives[0].replace(';','\n')
#        print "\n new perspective \n"



##Stuff for examples and templates and directory
        p1 = wx.Panel(self, -1)
#        p1.SetBackgroundColour("pink")

#        p2 = wx.Panel(self.split, style=sty)
#        p2.SetBackgroundColour("blue")
    
#        self.split.SetMinimumPaneSize(40)
#        self.split.SplitHorizontally(p1, p2, 200)


        self.notebook_dir = wx.aui.AuiNotebook(p1,id=-1,style=wx.aui.AUI_NB_WINDOWLIST_BUTTON|wx.aui.AUI_NB_TAB_MOVE|wx.aui.AUI_NB_TAB_SPLIT|wx.aui.AUI_NB_LEFT|wx.aui.AUI_NB_SCROLL_BUTTONS)
        sizer = wx.BoxSizer(wx.HORIZONTAL) #top left
        sizer.Add(self.notebook_dir, 1, wx.EXPAND, 0)#add directory control
        p1.SetSizer(sizer)
#        self.notebook_dir.SetControlBackgroundColour("pink")


        self.directory_panel=wx.Panel(self.notebook_dir,-1)
        self.window_Dir = wx.GenericDirCtrl(self.directory_panel, -1,
            filter  = "Python (*.py;*.pyw;*.tpy)|*.py;*.pyw;*.tpy|MATLAB/octave (*.m;*.txt)|*.m;*.txt|Backup files (*.bak)|*.bak|All files (*)|*",
            style   = wx.DIRCTRL_SHOW_FILTERS)
        sizer_directory = wx.BoxSizer(wx.HORIZONTAL) #top left
        sizer_directory.Add(self.window_Dir, 1, wx.EXPAND, 0)#add directory control
        self.directory_panel.SetAutoLayout(True) #set autolayout for upper left pane
        self.directory_panel.SetSizer(sizer_directory) #set size using upper left pane
        self.notebook_dir.AddPage(page=self.directory_panel, caption="Directory")#add notebook pane tab
        self.window_Dir.SetPath(os.path.join(os.getcwd(),'work'))
        self.dir_tree= self.window_Dir.GetTreeCtrl()


        self.window_template=wx.Panel(self.notebook_dir,-1)
        self.template = wx.TreeCtrl(self.window_template, wx.NewId(),wx.DefaultPosition, wx.DefaultSize, wx.TR_HAS_BUTTONS)

        sizer_directory = wx.BoxSizer(wx.HORIZONTAL) #top left
        sizer_directory.Add(self.template, 1, wx.EXPAND, 0)#add directory control
        self.window_template.SetAutoLayout(True) #set autolayout for upper left pane
        self.window_template.SetSizer(sizer_directory) #set size using upper left pane
        self.notebook_dir.AddPage(page=self.window_template, caption="Templates")#add notebook pane tab
 #       self.template.SetPath(r"c:\junktmp\dist\GNU Octave 2.1.64\octave_files")
 #       self.dir_tree_template= self.template.GetTreeCtrl()

        isz = (16,16)
        il = wx.ImageList(isz[0], isz[1])
        fldridx     = il.Add(wx.ArtProvider_GetBitmap(wx.ART_FOLDER,      wx.ART_OTHER, isz))
        fldropenidx = il.Add(wx.ArtProvider_GetBitmap(wx.ART_FILE_OPEN,   wx.ART_OTHER, isz))
        fileidx     = il.Add(wx.ArtProvider_GetBitmap(wx.ART_NORMAL_FILE, wx.ART_OTHER, isz))
#        smileidx    = il.Add(images.getSmilesBitmap())

        self.template.SetImageList(il)
        self.il = il
        self.root = self.template.AddRoot("Templates")
        self.template.SetPyData(self.root, None)
        self.template.SetItemImage(self.root, fldridx, wx.TreeItemIcon_Normal)
        self.template.SetItemImage(self.root, fldropenidx, wx.TreeItemIcon_Expanded)
        DIR = os.getcwd()+file_sep+'Templates'
        self.template_directory=os.getcwd()+file_sep+'Templates'
        self.dir_walker(self.template,DIR,self.root, fldridx, fldropenidx, fileidx)

#         for f in os.listdir(DIR):
#             f_dir=DIR+file_sep+f
#             if os.path.isdir(f_dir):
#                 child = self.template.AppendItem(self.root, f)
#                 self.template.SetPyData(child, None)
#                 self.template.SetItemImage(child, fldridx, wx.TreeItemIcon_Normal)
#                 self.template.SetItemImage(child, fldropenidx, wx.TreeItemIcon_Expanded)
#                 for f2 in os.listdir(f_dir):
#                     f2_dir=f_dir+file_sep+f2
#                     id_dec=f2.find(".")
#                     next = self.template.AppendItem(child, f2[0:id_dec])
#                     self.template.SetPyData(next, f2_dir)
#                     self.template.SetItemImage(next, fileidx, wx.TreeItemIcon_Normal)
#                     self.template.SetItemImage(next, fileidx, wx.TreeItemIcon_Expanded)
#             else:
#                 f2=f
#                 f2_dir=DIR+file_sep+f2
#                 id_dec=f2.find(".")
#                 next = self.template.AppendItem(self.root, f2[0:id_dec])
#                 self.template.SetPyData(next, f2_dir)
#                 self.template.SetItemImage(next, fileidx, wx.TreeItemIcon_Normal)
#                 self.template.SetItemImage(next, fileidx, wx.TreeItemIcon_Expanded)
        self.template.Expand(self.root)


##        self.template.Bind(wx.EVT_LEFT_DCLICK, self.OnTemplateLeftDClick)
###        self.template.Bind(wx.EVT_RIGHT_DOWN, self.OnRightDown)
##        self.template.Bind(wx.EVT_RIGHT_UP, self.OnTemplateLeftDClick)


        self.window_examples=wx.Panel(self.notebook_dir,-1)
        self.examples = wx.TreeCtrl(self.window_examples, wx.NewId(),wx.DefaultPosition, wx.DefaultSize, wx.TR_HAS_BUTTONS)

        sizer_directory = wx.BoxSizer(wx.HORIZONTAL) #top left
        sizer_directory.Add(self.examples, 1, wx.EXPAND, 0)#add directory control
        self.window_examples.SetAutoLayout(True) #set autolayout for upper left pane
        self.window_examples.SetSizer(sizer_directory) #set size using upper left pane
        self.notebook_dir.AddPage(page=self.window_examples, caption="Examples")#add notebook pane tab
 #       self.template.SetPath(r"c:\junktmp\dist\GNU Octave 2.1.64\octave_files")
 #       self.dir_tree_template= self.template.GetTreeCtrl()

##        isz = (16,16)
##        il = wx.ImageList(isz[0], isz[1])
##        fldridx     = il.Add(wx.ArtProvider_GetBitmap(wx.ART_FOLDER,      wx.ART_OTHER, isz))
##        fldropenidx = il.Add(wx.ArtProvider_GetBitmap(wx.ART_FILE_OPEN,   wx.ART_OTHER, isz))
##        fileidx     = il.Add(wx.ArtProvider_GetBitmap(wx.ART_NORMAL_FILE, wx.ART_OTHER, isz))
#        smileidx    = il.Add(images.getSmilesBitmap())

        self.examples.SetImageList(il)
        self.i2 = il
        self.root2 = self.examples.AddRoot("Examples")
        self.examples.SetPyData(self.root2, None)
        self.examples.SetItemImage(self.root2, fldridx, wx.TreeItemIcon_Normal)
        self.examples.SetItemImage(self.root2, fldropenidx, wx.TreeItemIcon_Expanded)
        DIR = os.getcwd()+file_sep+'Examples'
        self.examples_dir=os.getcwd()+file_sep+'Examples'
        self.dir_walker(self.examples,DIR,self.root2, fldridx, fldropenidx, fileidx)
#        for f in os.listdir(DIR):
#            f_dir=DIR+file_sep+f
#            if os.path.isdir(f_dir):
#                child = self.examples.AppendItem(self.root2, f)
#                self.examples.SetPyData(child, None)
#                 self.examples.SetItemImage(child, fldridx, wx.TreeItemIcon_Normal)
#                 self.examples.SetItemImage(child, fldropenidx, wx.TreeItemIcon_Expanded)
#                 for f2 in os.listdir(f_dir):
#                     f2_dir=f_dir+file_sep+f2
#                     id_dec=f2.find(".")
#                     next = self.examples.AppendItem(child, f2[0:id_dec])
#                     self.examples.SetPyData(next, f2_dir)
#                     self.examples.SetItemImage(next, fileidx, wx.TreeItemIcon_Normal)
#                     self.examples.SetItemImage(next, fileidx, wx.TreeItemIcon_Expanded)
#             else:
#                 f2=f
#                 f2_dir=DIR+file_sep+f2
#                 id_dec=f2.find(".")
#                 next = self.examples.AppendItem(self.root2, f2[0:id_dec])
#                 self.examples.SetPyData(next, f2_dir)
#                 self.examples.SetItemImage(next, fileidx, wx.TreeItemIcon_Normal)
#                 self.examples.SetItemImage(next, fileidx, wx.TreeItemIcon_Expanded)
        self.examples.Expand(self.root2)




##        self.examples.Bind(wx.EVT_LEFT_DCLICK, self.OnExamplesLeftDClick)
###        self.template.Bind(wx.EVT_RIGHT_DOWN, self.OnRightDown)
##        self.examples.Bind(wx.EVT_RIGHT_UP, self.OnExamplesLeftDClick)
        self.notebook1.AddPage(page=p1, caption='EditControl')
        self.template.Bind(wx.EVT_LEFT_DCLICK, self.OnTemplateLeftDClick)
#        self.template.Bind(wx.EVT_RIGHT_DOWN, self.OnRightDown)
        self.template.Bind(wx.EVT_RIGHT_UP, self.OnTemplateLeftDClick)
        self.examples.Bind(wx.EVT_LEFT_DCLICK, self.OnExamplesLeftDClick)
#        self.template.Bind(wx.EVT_RIGHT_DOWN, self.OnRightDown)
        self.examples.Bind(wx.EVT_RIGHT_UP, self.OnExamplesLeftDClick)
        self.dir_tree.Bind(wx.EVT_LEFT_DCLICK, self.OnLeftDClick)
#        self.window_Dir.Bind(wx.EVT_TREE_SEL_CHANGED, self.OnLeftDClick)
        self.dir_tree.Bind(wx.EVT_RIGHT_DOWN, self.OnLeftDClick)
        self.dir_tree.Bind(wx.EVT_KEY_DOWN, self.OnDirKey)

        self.shell.push('import time;new_session_time=time.localtime();del shell,new_session_time;from namespace import *', silent=True, add_hist=False)
        self.shell.Bind(wx.stc.EVT_STC_DOUBLECLICK,self.OnGoToError)

        self.Title='SciPylot - Input Cell'

    def OnGoToError(self,event):
        event.Skip()
        the_text,pos=self.shell.GetCurLine()
        if "File" in the_text:
            start_fname=the_text.find('"',0)+1
            end_fname=the_text.find('"',start_fname)
            path=the_text[start_fname:end_fname]
            number_pos=the_text.rfind('line')+5
            end_number=the_text.rfind(',', number_pos)
            line_number=int(the_text[number_pos:end_number])
##            dlg = wx.MessageDialog(self, str(line_number),
##                                   path,
##                                   wx.OK | wx.ICON_INFORMATION
##                                   #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
##                                   )
##            dlg.ShowModal()
##            dlg.Destroy()
    
            if "Input_Cell" in path:
                current_selected=self.nbeditor.GetSelection()
                if not current_selected==0:
                    self.nbeditor.SetSelection(0)
                self.nbeditor.GetPage(0).GotoLine(line_number)
                self.nbeditor.Update()
                return
            else:    
                for index in xrange(self.nbeditor.GetPageCount()):
                    if path==self.nbeditor.GetPage(index).name:
                        self.nbeditor.SetSelection(index)
                        self.nbeditor.GetPage(index).GotoLine(line_number)
                        self.nbeditor.Update()
                        return
                   


        
    def dir_walker(self,the_tree,the_dir,the_level, fldridx, fldropenidx, fileidx):
        """recursive walking through directory to get the py* files, excluding pyc and pyo
           to generate the tree"""
        for f in os.listdir(the_dir):
            f_dir=the_dir+file_sep+f
            if os.path.isdir(f_dir):
                child = the_tree.AppendItem(the_level, f)
                the_tree.SetPyData(child, None)
                the_tree.SetItemImage(child, fldridx, wx.TreeItemIcon_Normal)
                the_tree.SetItemImage(child, fldropenidx, wx.TreeItemIcon_Expanded)
                self.dir_walker(the_tree,f_dir,child, fldridx, fldropenidx, fileidx)

            else:
                f2=f
                f2_dir=the_dir+file_sep+f2
                id_dec=f2.find(".")
                the_ending=f2[id_dec:]
                if "py" in the_ending and not("pyc" in the_ending or "pyo" in the_ending):
                    next = the_tree.AppendItem(the_level, f2[0:id_dec])
                    the_tree.SetPyData(next, f2_dir)
                    the_tree.SetItemImage(next, fileidx, wx.TreeItemIcon_Normal)
                    the_tree.SetItemImage(next, fileidx, wx.TreeItemIcon_Expanded)


    def OnClickHelp(self,event):#OnClick2DtoNotebook(self,event):
        pass


    def OnInsertInputCellHistory(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        row=event.GetRow()
        the_text=self.cell_hist_grid.GetCellValue(row,0)
        edit_page.AddText(the_text)
        event.Skip()

    def OnDeleteInputCellHistory(self,event):
        the_key=event.GetKeyCode()
        if the_key==wx.WXK_DELETE:
            row=row=self.cell_hist_grid.GetGridCursorRow()
            self.cell_hist_grid.DeleteRows(pos=row, numRows=1)
            self.cell_hist_grid.last_row-=1

        event.Skip()
    def OnOpenFileHistory(self,event):
        row=event.GetRow()
        path=self.file_hist_grid.GetCellValue(row,0)
        event.Skip()
        for index in xrange(self.nbeditor.GetPageCount()):
            if path==self.nbeditor.GetPage(index).name:
                self.nbeditor.SetSelection(index)
                return

        if os.path.isfile(path):
            file=os.path.basename(path)
            fid=open(path,'r')
            ftext=fid.read()
            fid.close()
            directory=path[0:path.rfind(os.pathsep)]
            self.OpenEditNotebookPage(directory=directory, name=path,caption=file, text=ftext)
            self.Title = 'SciPylot - '+path
        else:
            pass
    def addGridHistory(self, command, the_grid):
        # Append command into the_grid 
        time_string=':'.join(str(time.localtime()[0:6]).split(', '))
        time_string=time_string.replace(':',"/",2)
        time_string=time_string.replace(':'," ",1)
        row_height = int(13*(len(command.splitlines())+.4))

        row=the_grid.last_row
        the_grid.SetCellValue(row,0,command)
        the_grid.SetCellValue(row,1,time_string)
        the_grid.SetReadOnly(row,0)
        the_grid.SetReadOnly(row,1)
        the_grid.SetRowSize(row,row_height)
        the_grid.AppendRows()
        the_grid.last_row+=1
        the_grid.MakeCellVisible(the_grid.last_row,0)
            

    def OnDeleteFileHistory(self,event):
        the_key=event.GetKeyCode()
        if the_key==wx.WXK_DELETE:
            row=row=self.file_hist_grid.GetGridCursorRow()
            self.file_hist_grid.DeleteRows(pos=row, numRows=1)
            self.file_hist_grid.last_row-=1

        event.Skip()


    def OnOpenWorkspaceHistory(self,event):
        row=event.GetRow()
        path=self.workspace_hist_grid.GetCellValue(row,0)
        path=homedir+file_sep+"SciPylot"+file_sep+path
        if os.path.isfile(path):
            try:
                self.LoadWorkspace(path)
            except:
                pass    
        else:
            pass

    def OnDeleteWorkspaceHistory(self,event):
        the_key=event.GetKeyCode()
        if the_key==wx.WXK_DELETE:
            row=row=self.workspace_hist_grid.GetGridCursorRow()
            self.workspace_hist_grid.DeleteRows(pos=row, numRows=1)
            self.workspace_hist_grid.last_row-=1

        event.Skip()

    def OnRClickHistory(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        the_commands=[]
        row=self.hist_grid.GetGridCursorRow()
        try:
            upper_left=self.hist_grid.top_left[0]
            bottom=self.hist_grid.bottom_right[0]
        except:
            upper_left=row
            bottom=row
        if row==upper_left or row==bottom:
            for k in range(upper_left,bottom+1):
                the_commands.append(self.hist_grid.GetCellValue(k,0))
            the_text='\n'.join(the_commands)
            edit_page.AddText(the_text)
        self.hist_grid.ClearSelection()
        self.hist_grid.top_left=(row,0)
        self.hist_grid.bottom_right=(row,0)
        self.history_cell=(row,0)
        event.Skip()

    def OnSelectHistoryCell(self,event):
        self.history_cell=(self.hist_grid.GetGridCursorRow(),0)
        event.Skip()



    def OnSelectHistoryCells(self,event):
        if event.Selecting():
            self.hist_grid.top_left=event.GetTopLeftCoords()
            self.hist_grid.bottom_right=event.GetBottomRightCoords()
##        else:
##            self.hist_grid.top_left= (self.hist_grid.GetGridCursorRow(),0)
##            self.hist_grid.bottom_right=(self.hist_grid.GetGridCursorRow(),0)
        event.Skip()


#        top=self.hist_grid.SelectedCells.GetTopLeftCoords()[0]
##        print top,bottom
##        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
##        the_commands=[]
##        for k in range(top,bottom+1):
##            the_commands.append(self.hist_grid.GetCellValue(k,0))
##        the_text='\n'.join(the_commands)
##        edit_page.AddText(the_text)



    def OnLeftDClickHistory(self,event):
        row=event.GetRow()
        self.shell.AddText(self.hist_grid.GetCellValue(row,0))
        event.Skip()

    def OnRightDClickHistory(self,event):
        row=event.GetRow()
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.AddText(self.hist_grid.GetCellValue(row,0)+'\n')
        event.Skip()

    def OnHistDelete(self,event):
        the_key=event.GetKeyCode()
        if the_key==wx.WXK_DELETE:
            row=self.hist_grid.GetGridCursorRow()
            try:
                upper_left=self.hist_grid.top_left[0]
                bottom=self.hist_grid.bottom_right[0]
            except:
                upper_left=row
                bottom=row    
            
            if (row==upper_left or row==bottom) and bottom!=self.hist_grid.GetNumberRows()-1:
                numRows=bottom-upper_left+1
                self.hist_grid.DeleteRows(pos=upper_left, numRows=numRows)
            else:
                numRows=1
                self.hist_grid.DeleteRows(pos=row, numRows=1)
            self.hist_grid.last_row-=numRows             
        hist=[]
        for row in xrange(self.hist_grid.last_row):
            hist.append(self.hist_grid.GetCellValue(row,0))

        self.shell.history=hist
        self.shell.history.reverse()


           
        event.Skip()
        
    def OnGraphSize(self,event):
        index=self.help_notebook.GetSelection()
        help_page=self.help_notebook.GetPage(index)
        try:
            if help_page.page_type=='2dGraph':
                help_page.canvas.Maximize(False)
                help_page.canvas.Maximize(True)
                the_label = self.help_notebook.GetPageText(index)
                idx=the_label.find(' ')
                fig_number=int(the_label[(idx+1):])
                namespace.figure(fig_number)
                event.Skip()
            else:
                event.Skip()        
        except:
            event.Skip()

    

    def OnEmbed2DFigure(self,event):
        if wx.Platform != '__WXMSW__':
            dlg = wx.MessageDialog(self, 'Only Supported in Windows',
                                   'Only Supported in Windows',
                                   wx.OK | wx.ICON_INFORMATION
                                   #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                                   )
            dlg.ShowModal()
            dlg.Destroy()

            pass   
        else:
            my_panel=wx.Panel(self,-1)
            cur_fig=namespace.gcf()
            cur_canvas=cur_fig.canvas.GetParent()
            name=cur_canvas.Title
            cur_canvas.Reparent(my_panel)
            
            self.help_notebook.AddPage(page=my_panel,caption=name)
            cur_canvas.Maximize()
            idx=self.help_notebook.GetPageCount()-1                    
            self.help_notebook.SetSelection(idx)
            
    #        self.help_notebook.Bind(wx.aui.EVT_AUI_PANE_MAXIMIZE, self.OnGraphSize)
    #        self.help_notebook.Bind(wx.aui.EVT_AUI_PANE_RESTORE, self.OnGraphSize)
            help_page=self.help_notebook.GetPage(self.help_notebook.GetSelection())
            help_page.canvas=cur_canvas
            help_page.page_type='2dGraph'

    def OnClick3DtoNotebookOn(self,event):#OnClickHelp(self,event):
        self.mayavi_view = MayaviView()
        namespace.p3d.set_engine(self.mayavi_view.scene.engine)
#        namespace.p3d.test_contour3d()
#        my_panel=wx.Panel(self,-1)
#        my_scene=namespace.p3d.get_engine().current_scene

#        my_viewer=namespace.p3d.get_engine().get_viewer(my_scene)

        my_control=self.mayavi_view.edit_traits(
                        parent=self,
                        kind='subpanel').control

                        
        name = "3D scene 1"
        
        self.help_notebook.AddPage(page=my_control,caption=name)

        idx=self.help_notebook.GetPageCount()-1                    
        self.help_notebook.SetSelection(idx)
        help_page= self.help_notebook.GetPage(idx)
        engine1=namespace.p3d.get_engine()
        num_scene=len(engine1.scenes)-1
        help_page.scene=engine1.scenes[num_scene]

        if num_scene!=0:
#            import copy
            help_page.scene.children=engine1.scenes[num_scene-1].children
            engine1.scenes[num_scene-1].set(children=[], trait_change_notify=False)
            namespace.p3d.get_engine().close_scene(engine1.scenes[num_scene-1])
           
    def OnCloseNotebookPage(self,event):
        index = event.GetSelection()
        if index==0:
            event.Veto()
        else:    
            edit_page=self.nbeditor.GetPage(index)
            if edit_page.dirty:
                dlg = wx.MessageDialog(self, edit_page.name+' has been changed\nDo you want to save it before closing?',
                               'Save File '+edit_page.name+'?',
                               #wx.OK | wx.ICON_INFORMATION
                               wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL 
                               )
                result=dlg.ShowModal()
                if  result == wx.ID_YES:
                    self.OnSave(event)
                    dlg.Destroy()
                    event.Skip()
                elif result == wx.ID_NO:
                    event.Skip()
                    dlg.Destroy()
                else:
                    dlg.Destroy()
                    event.Veto()
            else:
                event.Skip()                                        
    def OnCloseHelpPage(self,event):
        index = event.GetSelection()
        the_label = self.help_notebook.GetPageText(index)
        
        if the_label in ['Calltip']:
            event.Veto()
        elif the_label[0:3]=='Fig':
            idx=the_label.find(' ')
            fig_number=int(the_label[(idx+1):])
            namespace.close(fig_number)
            event.Skip()
        elif the_label[0:2]=='3D':
            help_page=self.help_notebook.GetPage(index)
            namespace.p3d.get_engine().close_scene(help_page.scene)
            event.Skip()
        else:    
            event.Skip()

            

#    def OnEditPageClose(self,event):


    def OnSave(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        if edit_page.name=='Input_Cell':
            self.OnSaveAs(event)
        else:
            edit_page.onSave(event)
            edit_page.dirty=False
            if self.Title[-1]=='*':
                self.Title=self.Title[0:-1]
            if edit_page.name[-1]=='*':
                edit_page.name=edit_page.name[0:-1]   
            tab_text=self.nbeditor.GetPageText(self.nbeditor.GetSelection())
    
        
            if tab_text[-1]=='*':
                self.nbeditor.SetPageText(self.nbeditor.GetSelection(),tab_text[0:-1])
 
    def OnSaveAs(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
#        edit_page.onSaveAs(event)
        if edit_page.name=='Input_Cell':
            ftext=edit_page.GetText()
            ftext=ftext.replace("\r","")


            defaultDir=os.getcwd()
            defaultFile=""
            dlg = wx.FileDialog(
                self, message="Save file as ...", defaultDir=defaultDir,
                defaultFile=defaultFile, wildcard=wildcard, style=wx.SAVE|wx.OVERWRITE_PROMPT
                )

            dlg.SetFilterIndex(0)

            # Show the dialog and retrieve the user response. If it is the OK response,
            # process the data.
            if dlg.ShowModal() == wx.ID_OK:
                path = dlg.GetPath()
                defaultDir=path[0:(path.rfind(os.path.sep)):]
                defaultFile=os.path.basename(path)  
                self.OpenEditNotebookPage(directory=defaultDir, name=path,caption=defaultFile, text=ftext)
#                self.addGridHistory(path, self.file_hist_grid)            
                self.nbeditor.GetPage(0).SetText('')
                dlg.Destroy()
            else:
                dlg.Destroy()
                return

            fid=open(path,'w')
            fid.write(ftext)
            fid.close()
            return
            
        else:
            edit_page.onSaveAs(event)
            edit_page.dirty=False
            self.Title='SciPylot - '+edit_page.name

    def OnSaveAll(self,event):
        for index in xrange(self.nbeditor.GetPageCount()):
            edit_page=self.nbeditor.GetPage(index)
            if edit_page.dirty:
                edit_page.onSave(event)
                edit_page.dirty=False
                tab_text=self.nbeditor.GetPageText(index)
                if tab_text[-1]=='*':  
                    self.nbeditor.SetPageText(index,tab_text[0:-1])
                
        if self.Title[-1]=='*':
            self.Title=self.Title[0:-1]
            
    def LoadWorkspace(self,fname):
        the_layout=[]
        parse(fname, GeneralXMLHandler(the_layout,'layout'))
        the_files=[]
        parse(fname, GeneralXMLHandler(the_files,'file'))
        the_frame_size=[]
        parse(fname, GeneralXMLHandler(the_frame_size,'framesize'))
        the_position=[]
        parse(fname, GeneralXMLHandler(the_position,'position'))

        if len(the_frame_size)==1:
            exec("(width,height)="+the_frame_size[0])
            self.SetSize(wx.Size(width,height))
        if len(the_position)==1:
            exec("(from_left,from_top)="+the_position[0])
            self.SetPosition(wx.Point(from_left,from_top))
        for path in the_files:
            directory=path[0:(path.rfind(os.path.sep)):]
            file=os.path.basename(path)
            try:
                fid=open(path,'r')
                ftext=fid.read()
                fid.close()
                self.OpenEditNotebookPage(directory=directory, name=path,caption=file, text=ftext)
                self.Title = 'SciPylot - '+path
            except:
                print "file "+path+" not found"
        self._mgr.LoadPerspective(the_layout[0])



    def OnOpenWorkspace(self,event):
        xml_wildcard = "XML (*.xml)|*.xml"

        dlg = wx.FileDialog(
            self, message="Workspace File to Open", defaultDir=homedir+file_sep+"SciPylot",
            wildcard=xml_wildcard, style=wx.OPEN
            )

        dlg.SetFilterIndex(0)

        # Show the dialog and retrieve the user response. If it is the OK response,
        # process the data.
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            dlg.Destroy()
        else:
            dlg.Destroy()
            return

        self.LoadWorkspace(path)
##        last_perspective=self._mgr.SavePerspective()
##        text="<workspace>\n"
##        text=text+"<layout>"+last_perspective+"<layout>\n"
##        for index in xrange(1,self.nbeditor.GetPageCount()):                   
##            edit_page=self.nbeditor.GetPage(index)
##            text="<file>"+edit_page.name+"</file>\n"
##        text=text+"</workspace>"

    def OnPrintInputFile(self,event):
# To print from any directory:
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        ftext = edit_page.GetText()
        #f = open(edit_page.name)
        #ff = f.read()
        #self.printer.Print(ff, "Printing")
        self.printer.Print(ftext, "Printing")
### To print from current directory where "scipylot.py" is:
##        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
##        if edit_page.name[-1]=='*':
##                edit_page.name=edit_page.name[0:-1]   
##        tab_text=self.nbeditor.GetPageText(self.nbeditor.GetSelection())
##        #f = open(tab_text,'r')
##        #ff = f.read()
##        #self.printer.Print(ff, "Printing")
##        
##        former, sys.stdout = sys.stdout, open('output.txt', 'w')
##        execfile(tab_text)
##        results, sys.stdout = sys.stdout, former
##        results.close()
##        f = open('output.txt','r')
##        ff = f.read()
##        self.printer.Print(ff, "Printing")
##        f.close()

    def OnPrintOutputFile(self,event):
    # To print from any directory:
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        former, sys.stdout = sys.stdout, open('output.txt', 'w')
        execfile(edit_page.name)
        results, sys.stdout = sys.stdout, former
        results.close()
        f = open('output.txt','r')
        ff = f.read()
        self.printer.Print(ff, "Printing")
        f.close()
    
    def OnSaveWorkspace(self,event, path=None):
        if path==None:
            xml_wildcard = "XML (*.xml)|*.xml"
            dlg = wx.FileDialog(
                self, message="Save Workspace as ...", defaultDir=homedir+file_sep+"SciPylot",
                wildcard=xml_wildcard, style=wx.SAVE|wx.OVERWRITE_PROMPT
                )
    
            dlg.SetFilterIndex(0)
    
            # Show the dialog and retrieve the user response. If it is the OK response,
            # process the data.
            if dlg.ShowModal() == wx.ID_OK:
                path = dlg.GetPath()
                dlg.Destroy()
            else:
                dlg.Destroy()
                return
        last_perspective=self._mgr.SavePerspective()
        text="<workspace>\n"
        text+="<framesize>"+ str(self.Size)+"</framesize>"
        text+="<position>"+str(self.Position)+"</position>"

        text=text+"<layout>"+last_perspective+"</layout>\n"
        for index in xrange(1,self.nbeditor.GetPageCount()):                   
            edit_page=self.nbeditor.GetPage(index)
            text=text+"<file>"+edit_page.name+"</file>\n"
        text=text+"</workspace>"
        f_idx=path.rfind(file_sep)+1
        self.addGridHistory(path[f_idx:], self.workspace_hist_grid)
        
#        path = homedir+file_sep+"SciPylot"+file_sep+'last_workspace.xml'  
        fid=open(path,'w')
        fid.write(text)
        fid.close()                                    

    def OnRecentFiles(self,event):
        pass
    def OnNew(self,event):
        name='New_Edit'+str(self.NewFileKount)
        self.nbeditor.AddPage(page=stc.PythonBaseSTC(self,-1, calltip_window=self.crust.calltip,shell=self.crust.shell,name=name, namespace=self.crust.shell.interp.locals,keywordlist=namespace.__dict__),caption=name)
        idx=self.nbeditor.GetPageCount()-1                    
        edit_page=self.nbeditor.GetPage(idx)
        edit_page.dirty=False
        self.nbeditor.SetSelection(idx)
        self.NewFileKount+=1
        self.Title='SciPylot - '+name
        wx.stc.EVT_STC_CHARADDED(edit_page, edit_page.GetId(), self._on_stc_changed)        
        drop_target=TheFileDropTarget(self,self.nbeditor)
        edit_page.SetDropTarget(drop_target)

    def OnOpenFile(self,event):
        defaultDir=os.getcwd()
        defaultFile=""
        dlg = wx.FileDialog(
            self, message="Open File", defaultDir=defaultDir,
            defaultFile=defaultFile, wildcard=wildcard, style=wx.OPEN
            )
        dlg.SetFilterIndex(0)

        # Show the dialog and retrieve the user response. If it is the OK response,
        # process the data.
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            dlg.Destroy()
            #do not allow more than one instance of file
            for index in xrange(self.nbeditor.GetPageCount()):
                if path==self.nbeditor.GetPage(index).name:
                    self.nbeditor.SetSelection(index)
                    return
                    
            directory=path[0:(path.rfind(os.path.sep)):]
            file=os.path.basename(path)
            fid=open(path,'r')
            ftext=fid.read()
            fid.close()
            self.OpenEditNotebookPage(directory=directory, name=path,caption=file, text=ftext)
            self.Title = 'SciPylot - '+path


        else:
            dlg.Destroy()
            return

    def OnExit(self,event):
        self.Close(True)

#wx.stc.EVT_STC_CHANGE
    def OnLeftDClick(self, event):
        event.Skip()
        path    = self.window_Dir.GetFilePath()
        #do not allow more than one instance of file
        for index in xrange(self.nbeditor.GetPageCount()):
            if path==self.nbeditor.GetPage(index).name:
                self.nbeditor.SetSelection(index)
                return

        if os.path.isfile(path):
            file=os.path.basename(path)
            fid=open(path,'r')
            ftext=fid.read()
            fid.close()
            directory=path[0:path.rfind(os.pathsep)]
            self.OpenEditNotebookPage(directory=directory, name=path,caption=file, text=ftext)
            self.Title = 'SciPylot - '+path
        else:
            pass

    def OnDirKey(self, event):

        key     = event.GetKeyCode()
        control = event.ControlDown()
        #shift=event.ShiftDown()
        alt     = event.AltDown()
        if key == wx.WXK_DELETE:
            #auto-indentation
            file    = self.window_Dir.GetFilePath()
            root=self.window_Dir.GetPath()

                        
            if os.path.isfile(file): 
                os.remove(file)
                self.window_Dir.CollapsePath(root)
                self.window_Dir.ExpandPath(root)
            else:
                pass    



        event.Skip()




    def OpenEditNotebookPage(self,directory=os.getcwd(), name="NewEdit",caption="NewEdit", text=''):
        self.nbeditor.AddPage(page=stc.PythonBaseSTC(self,-1, calltip_window=self.crust.calltip,
                              defaultdirectory=directory, shell=self.crust.shell,name=name, namespace=self.crust.shell.interp.locals, keywordlist=namespace.__dict__),caption=caption)
        idx=self.nbeditor.GetPageCount()-1                    
        page=self.nbeditor.GetPage(idx)                    
        page.SetText(text)
        page.dirty=False
        self.nbeditor.SetSelection(idx)
        # Listen for changes to the file.
        wx.stc.EVT_STC_CHARADDED(page, page.GetId(), self._on_stc_changed)
        drop_target=TheFileDropTarget(self,self.nbeditor)
        page.SetDropTarget(drop_target)

    #### wx event handlers ####################################################

    def _on_stc_changed(self, event):
        """ Called whenever a change is made to the text of the document. """
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        if edit_page.dirty != True:
            edit_page.dirty = True

            self.Title = 'SciPylot - '+edit_page.name+'*'
            tab_text=self.nbeditor.GetPageText(self.nbeditor.GetSelection())
            self.nbeditor.SetPageText(self.nbeditor.GetSelection(),tab_text+'*')

        # Give other event handlers a chance.
        event.Skip()
        
        return
        
            
    def OnUndo(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.Undo()

    def OnRedo(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.Redo()

    def OnCopy(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.Copy()
    def OnCut(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.Cut()


    def OnPaste(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.Paste()

    def OnPasteRectangle(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        do = wx.TextDataObject()
        wx.TheClipboard.GetData(do)
        text = do.GetText() # from clipboard
        text=text.replace('\r','')
        ind = 0
        pos = edit_page.GetCurrentPos()
        oldpos = pos
        line = edit_page.GetCurrentLine()
        col = edit_page.GetColumn(edit_page.GetCurrentPos())
        while text.find('\n', ind) != -1:
                newind = text.find('\n', ind)
                temp = text [ind:newind]
                edit_page.AddText(temp)
                edit_page.GotoPos(pos)
                edit_page.CmdKeyExecute (wx.stc.STC_CMD_LINEDOWN)
                pos = edit_page.GetCurrentPos()
                line += 1
                ind = newind+1
        edit_page.GotoPos(oldpos)

    def OnSelectRectangle(self,event):
        dlg = wx.MessageDialog(self, 'To select columns of text, hold the ALT key down before and during selection. \n\nTo paste as a rectangle, go to the new position, then Edit->Paste Rectangular',
                              'Column/Rectagular Selection',
                               wx.OK | wx.ICON_INFORMATION
                               #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                               )
        dlg.ShowModal()
        dlg.Destroy()


    def OnSelectAll(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.SelectAll()

    def OnIndent(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.onIndent(event)

    def OnDedent(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.onUnindent(event)

    def OnComment(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.onComment(event)

    def OnUncomment(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.onUncomment(event)


    def OnFindSet(self, evt):
        map = {
            wx.wxEVT_COMMAND_FIND : "FIND",
            wx.wxEVT_COMMAND_FIND_NEXT : "FIND_NEXT",
            wx.wxEVT_COMMAND_FIND_REPLACE : "REPLACE",
            wx.wxEVT_COMMAND_FIND_REPLACE_ALL : "REPLACE_ALL",
            }

        et = evt.GetEventType()
        text=evt.GetFindString()
        if evt.GetFlags()==1:
            flags=0
        elif evt.GetFlags()==3:
            flags=wx.stc.STC_FIND_WHOLEWORD
        elif evt.GetFlags()==5: 
            flags=wx.stc.STC_FIND_MATCHCASE
        else:
            flags=wx.stc.STC_FIND_WHOLEWORD|wx.stc.STC_FIND_MATCHCASE
       
        if et==wx.wxEVT_COMMAND_FIND:
            pos=self.activepage.SearchNext(flags,text)
            if pos==-1:
                dlg = wx.MessageDialog(self, 'No Match Found!',
                                       'Search Message',
                                       wx.OK | wx.ICON_INFORMATION
                                       #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                                       )
                dlg.ShowModal()
                dlg.Destroy()
            else:
                self.activepage.SetAnchor(pos+len(text))
                self.activepage.SetCurrentPos(len(self.activepage.GetText()))
                self.activepage.SearchAnchor()
                self.activepage.SetCurrentPos(pos)
                self.activepage.ScrollToLine(self.activepage.LineFromPosition(pos))
                        
        elif et==wx.wxEVT_COMMAND_FIND_NEXT:
            pos=self.activepage.SearchNext(flags,text)
            if pos==-1:
                dlg = wx.MessageDialog(self, 'No Match Found!',
                                       'Search Message',
                                       wx.OK | wx.ICON_INFORMATION
                                       #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                                       )
                dlg.ShowModal()
                dlg.Destroy()
            else:
                self.activepage.SetAnchor(pos+len(text))
                self.activepage.SetCurrentPos(len(self.activepage.GetText()))
                self.activepage.SearchAnchor()
                self.activepage.SetCurrentPos(pos)
                self.activepage.ScrollToLine(self.activepage.LineFromPosition(pos))
 
        elif et ==wx.wxEVT_COMMAND_FIND_REPLACE:
            replaceTxt = evt.GetReplaceString()
            pos=self.activepage.SearchNext(flags,text)
            if pos==-1:
                dlg = wx.MessageDialog(self, 'No Match Found!',
                                       'Search Message',
                                       wx.OK | wx.ICON_INFORMATION
                                       #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                                       )
                dlg.ShowModal()
                dlg.Destroy()
            else:            
                self.activepage.SetAnchor(pos+len(text))
                self.activepage.SetCurrentPos(len(self.activepage.GetText()))
                self.activepage.SearchAnchor()
                self.activepage.SetCurrentPos(pos)
                self.activepage.SetTargetStart(pos)      
                self.activepage.SetTargetEnd(pos+len(text))
                self.activepage.ReplaceTarget(replaceTxt)
                self.activepage.ScrollToLine(self.activepage.LineFromPosition(pos))
            
        elif et== wx.wxEVT_COMMAND_FIND_REPLACE_ALL:
            old_pos=self.activepage.GetAnchor()
            replaceTxt = evt.GetReplaceString()
            pos=1
            kount=0
            hold_text=self.activepage.GetText()
            found_match=False
            while pos!=-1:
                pos=self.activepage.SearchNext(flags,text)
                if pos!=-1:
                    found_match=True
                    kount+=1
                    self.activepage.SetAnchor(pos+len(text))
                    self.activepage.SetCurrentPos(len(self.activepage.GetText()))
                    self.activepage.SearchAnchor()
                    self.activepage.SetCurrentPos(pos)
                    self.activepage.SetTargetStart(pos)      
                    self.activepage.SetTargetEnd(pos+len(text))
                    self.activepage.ReplaceTarget(replaceTxt)

            if found_match:

                message='Made %s Substitutions' % str(kount)    
                dlg = wx.MessageDialog(self, message,
                                       'Matches Found',
                                       wx.OK | wx.ICON_INFORMATION
                                       #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                                       )
                dlg.ShowModal()
                dlg.Destroy()
                new_text=self.activepage.GetText()
                self.activepage.SetText(hold_text)
                self.activepage.SetAnchor(old_pos)
                self.activepage.ScrollToLine(self.activepage.LineFromPosition(old_pos))
                self.activepage.SetText(new_text)
                self.activepage.SetAnchor(old_pos)
                self.activepage.ScrollToLine(self.activepage.LineFromPosition(old_pos))
                
            else:    
                dlg = wx.MessageDialog(self, 'No Match Found!',
                                       'Search Message',
                                       wx.OK | wx.ICON_INFORMATION
                                       #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
                                       )
                dlg.ShowModal()
                dlg.Destroy()

                
      
                        


    def OnFindClose(self, evt):
        self.finddialog.Destroy() 
        self.FindActive=False

    def OnFind(self,event):
        if self.FindActive:
            pass
        else:            
            self.FindActive=True
            edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
            edit_page.SearchAnchor()
            (start,end)=edit_page.GetSelection()
            self.activepage=edit_page        
            data = wx.FindReplaceData()
            dlg = wx.FindReplaceDialog(self, data, "Find & Replace", wx.FR_REPLACEDIALOG)
            dlg.data = data  # save a reference to it...
            self.finddialog=dlg
            dlg.Show(True)

    def OnFindAgain(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.onFindAgain(event)
        self.activepage=None

    def OnReplace(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.onReplace(event)

    def OnRunInShell(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        if edit_page.name=="Input_Cell":
            ftext= (edit_page.GetText()).replace('\r\n','\n')            
            self.addGridHistory(ftext, self.cell_hist_grid)
#        else:    
#            self.addGridHistory(edit_page.name, self.file_hist_grid)            

        edit_page.RunFile(event)
        edit_page.dirty=False
        if self.Title[-1]=='*':
            self.Title=self.Title[0:-1]
        if edit_page.name[-1]=='*':
            edit_page.name=edit_page.name[0:-1]   
        tab_text=self.nbeditor.GetPageText(self.nbeditor.GetSelection())
        
    
        if tab_text[-1]=='*':
            self.nbeditor.SetPageText(self.nbeditor.GetSelection(),tab_text[0:-1])
        if not edit_page.name=="Input_Cell":
            self.addGridHistory(edit_page.name, self.file_hist_grid)            
        

    def OnRunExternally(self,event):
        self.run_with_arguments(event)

    def run_with_arguments(self,event, arguments='', inspct=False, exit=False, confirm=True):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        name=edit_page.name
        if name=="Input_Cell":
            fsync='Input_Cell.py'
            ftext= (self.GetText()+'\n').replace('\r\n','\n')
            fout=open(fsync,'w')
            fout.write(ftext)
            fout.close()
            path=os.getcwd()
            fileName=name
            self.addGridHistory(ftext, self.cell_hist_grid)

        else:
            self.OnSave(event)
            path, fileName  = os.path.split(name)            


        # todo: input stuff from preferences dialog box!

        params          = { 'file':         fileName,
                            'path':         path,
                            'arguments':    arguments,
                            'python':       sys.executable+['',' -i'][inspct]}
        PLATFORM                    = sys.platform
        WIN                         = PLATFORM.startswith('win')
        DARWIN                      = PLATFORM.startswith('darwin')
        LINUX                       = not (WIN or DARWIN)
        params['python']=params['python'].replace('pythonw','python')
        if WIN:
            windowsVer = sys.getwindowsversion()
            if (windowsVer[3] == 1 ):
                WIN98   = True
            else:
                WIN98   = False
        else:
            WIN98       = False

        if WIN:
            if WIN98:
                params['start'] = 'start command'
            else:
                params['start'] = 'start "SciPylot - %(file)s - Press Ctrl+Break to stop" /D"%(path)s" cmd'%params
            if exit:
                os.system('%(start)s /c %(python)s "%(file)s" %(arguments)s'%params)
            else:
                os.system('%(start)s /k %(python)s "%(file)s" %(arguments)s'%params)
        elif DARWIN:
            commandList = [
                    ['cd', params['path']],
                    [params['python'], params['file'], [params['arguments']]]
                    ]
            if exit:
                commandList.append(['exit'])
            self.startAppleScript(commandList, activateFlag=True)
        elif os.path.isfile('/usr/bin/gnome-terminal'):
            if exit:
                os.system("""/usr/bin/gnome-terminal --title "SciPylot - %(file)s - %(path)s - Press Ctrl+C to stop" --working-directory="%(path)s" -e '%(python)s "%(file)s" %(arguments)s' &"""%params)
            else:
                os.system("""/usr/bin/gnome-terminal --title "SciPylot - %(file)s - %(path)s - Press Ctrl+C to stop" --working-directory="%(path)s" -x bash -c "%(python)s \\"%(file)s\\" %(arguments)s; cat" """%params)
        elif os.path.isfile('/usr/bin/konsole'):
            if exit:
                os.system("""/usr/bin/konsole --caption SciPylot --workdir "%(path)s" -e %(python)s "%(file)s" %(arguments)s &"""%params)
            else:
                os.system("""/usr/bin/konsole --caption SciPylot --noclose --workdir "%(path)s" -e %(python)s "%(file)s" %(arguments)s &"""%params)
        else:
            os.system('%(python)s "%(file)s" %(arguments)s'%params)

        edit_page.dirty=False
        if self.Title[-1]=='*':
            self.Title=self.Title[0:-1]
        if edit_page.name[-1]=='*':
            edit_page.name=edit_page.name[0:-1]   
        tab_text=self.nbeditor.GetPageText(self.nbeditor.GetSelection())

    
        if tab_text[-1]=='*':
            self.nbeditor.SetPageText(self.nbeditor.GetSelection(),tab_text[0:-1])



    def startAppleScript(commandList, activateFlag = True):
        """Start a list of commands in the terminal window.
        Each command is a list of program name, parameters.
        Handles the quoting properly through shell, applescript and shell again.
        """
        def adjustParameter(parameter):
            """Adjust a parameter for the shell.
            Adds single quotes,
            unless the parameter consists of letters only
            (to make shell builtins work)
            or if the parameter is a list
            (to flag that it already is list a parameters).
            """
            if isinstance(parameter, list): return parameter[0]
            if parameter.isalpha(): return parameter
            #the single quote proper is replaced by '\'' since
            #backslashing a single quote doesn't work inside a string
            return "'%s'"%parameter.replace("'",r"'\''")
        command = ';'.join([
            ' '.join([
                adjustParameter(parameter)
                for parameter in command
                ])
            for command in commandList
        ])
        #make Applescript string from this command line:
        #put backslashes before double quotes and backslashes
        command = command.replace('\\','\\\\').replace('"','\\"')
        #make complete Applescript command containing this string
        command = 'tell application "Terminal" to do script "%s"'%command
        #make a shell parameter (single quote handling as above)
        command = command.replace("'","'\\''")
        #make complete shell command
        command = "osascript -e '%s'"%command
        #prepend activate command if needed
        if activateFlag:
            command = "osascript -e 'tell application \"Terminal\" to activate';"+command
        #go!
        os.popen(command)

    def OnImportInShell(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        pass

    def OnDebug(self,event):
##        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
##        name=edit_page.name
##        path, fileName  = os.path.split(name)            
##        curr_dir=os.getcwd()
##        os.chdir(path)
##        os.popen('winpdb '+fileName)
##        os.chdir(curr_dir)
        arguments='' 
        inspct=False 
        exit=False 
        confirm=True
        
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        name=edit_page.name
        if name=="Input_Cell":
            fsync='Input_Cell.py'
            ftext= (self.GetText()+'\n').replace('\r\n','\n')
            fout=open(fsync,'w')
            fout.write(ftext)
            fout.close()
            path=os.getcwd()
            fileName=name
        else:
            self.OnSave(event)
            path, fileName  = os.path.split(name)            


        # todo: input stuff from preferences dialog box!

        params          = { 'file':         fileName,
                            'path':         path,
                            'arguments':    arguments,
                            'python':       'winpdb '}#sys.executable+['',' -i'][inspct]}
        PLATFORM                    = sys.platform
        WIN                         = PLATFORM.startswith('win')
        DARWIN                      = PLATFORM.startswith('darwin')
        LINUX                       = not (WIN or DARWIN)

        if WIN:
            windowsVer = sys.getwindowsversion()
            if (windowsVer[3] == 1 ):
                WIN98   = True
            else:
                WIN98   = False
        else:
            WIN98       = False

        if WIN:
            if WIN98:
                params['start'] = 'start command'
            else:
                params['start'] = 'start "SciPylot - %(file)s - Press Ctrl+Break to stop" /D"%(path)s" cmd'%params
            if exit:
                os.system('%(start)s /c %(python)s "%(file)s" %(arguments)s'%params)
            else:
                os.system('%(start)s /k %(python)s "%(file)s" %(arguments)s'%params)
        elif DARWIN:
            commandList = [
                    ['cd', params['path']],
                    [params['python'], params['file'], [params['arguments']]]
                    ]
            if exit:
                commandList.append(['exit'])
            self.startAppleScript(commandList, activateFlag=True)
        elif os.path.isfile('/usr/bin/gnome-terminal'):
            if exit:
                os.system("""/usr/bin/gnome-terminal --title "SciPylot - %(file)s - %(path)s - Press Ctrl+C to stop" --working-directory="%(path)s" -e '%(python)s "%(file)s" %(arguments)s' &"""%params)
            else:
                os.system("""/usr/bin/gnome-terminal --title "SciPylot - %(file)s - %(path)s - Press Ctrl+C to stop" --working-directory="%(path)s" -x bash -c "%(python)s \\"%(file)s\\" %(arguments)s; cat" """%params)
        elif os.path.isfile('/usr/bin/konsole'):
            if exit:
                os.system("""/usr/bin/konsole --caption SciPylot --workdir "%(path)s" -e %(python)s "%(file)s" %(arguments)s &"""%params)
            else:
                os.system("""/usr/bin/konsole --caption SciPylot --noclose --workdir "%(path)s" -e %(python)s "%(file)s" %(arguments)s &"""%params)
        else:
            os.system('%(python)s "%(file)s" %(arguments)s'%params)


    def OnRestoreLastPerspective(self,event):
#        self.OnRestorePane(wx.Control(self).Command(wx.aui.EVT_AUI_PANE_RESTORE))
        self._mgr.LoadPerspective(self.current_layout)
        self._mgr.Update()

#        self.OnRestorePane(wx.aui.EVT_AUI_PANE_RESTORE)
#        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
#        pass

    def OnProfile(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        pass

    def OnViewPane(self,event):

        id=event.GetId()
        if id==ID_EditPane:
            if self.menubar.FindItemById(id).IsChecked():
                self._mgr.GetPane("editor").Show()
            else:
                self._mgr.GetPane("editor").Hide()
        elif id==ID_ControlPane:
            if self.menubar.FindItemById(id).IsChecked():
                self._mgr.GetPane("workspace").Show()
            else:
                self._mgr.GetPane("workspace").Hide()
        elif id==ID_HelpPane:
            if self.menubar.FindItemById(id).IsChecked():
                self._mgr.GetPane("help").Show()
            else:
                self._mgr.GetPane("help").Hide()
        self._mgr.Update()
        event.Skip()




    def OnZoomLevel(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        levels= zoom_levels.keys()
        levels.sort()
        dlg = wx.SingleChoiceDialog(
        self, 'Zoom Level', 'Set the Zoom Level',
        levels,
        wx.CHOICEDLG_STYLE
        )

        if dlg.ShowModal() == wx.ID_OK:
            edit_page.SetZoom(zoom_levels[dlg.GetStringSelection()] )

        dlg.Destroy()



    def OnZoomIn(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.SetZoom(edit_page.GetZoom()+1)





    def OnZoomOut(self,event):
        edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
        edit_page.SetZoom(edit_page.GetZoom()-1)
        
    def onPageChanged(self, event):
        # On Windows, the AuiNotebook changes its pages when other applications
        # are minimized. Prevent this by vetoing PAGE_CHANGING events when our
        # top level window is not active:
        if '__WXMSW__' in wx.PlatformInfo and \
                not self.GetTopLevelParent().IsActive():
            event.Veto()
        else:
#            event.Skip()
            edit_page=self.nbeditor.GetPage(self.nbeditor.GetSelection())
            if edit_page.dirty:

                self.Title = 'SciPylot - '+edit_page.name+'*'
            else:
                self.Title = 'SciPylot - '+edit_page.name

        
    def OnPaneClose(self, event):

        event.GetPane().Hide()       
        name = event.GetPane().name
        if name=="editor":
            self.menubar.FindItemById(ID_EditPane).Check(check=False)
        if name=="workspace":
            self.menubar.FindItemById(ID_ControlPane).Check(check=False)
        if name=="help":
            self.menubar.FindItemById(ID_HelpPane).Check(check=False)
        event.Skip()
            
##
##        if name in ["help", "workspace", "editor"]:
##            msg = "Are You Sure You Want To Close This Pane?"
##            dlg = wx.MessageDialog(self, msg, "AUI Question",
##                                   wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
##
##            if dlg.ShowModal() in [wx.ID_NO, wx.ID_CANCEL]:
##                event.Veto()
##            dlg.Destroy()

        
    def OnClose(self, event):
        last_perspective=self._mgr.SavePerspective()
        text="<workspace>\n"
        text+="<framesize>"+ str(self.Size)+"</framesize>"
        text+="<position>"+str(self.Position)+"</position>"
        text=text+"<layout>"+last_perspective+"</layout>\n"
        for index in xrange(1,self.nbeditor.GetPageCount()):                   
            edit_page=self.nbeditor.GetPage(index)
            text=text+"<file>"+edit_page.name+"</file>\n"
            if edit_page.dirty:
                dlg = wx.MessageDialog(self, edit_page.name+' has been changed\nDo you want to save it before closing?',
                               'Save File '+edit_page.name+'?',
                               #wx.OK | wx.ICON_INFORMATION
                               wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL 
                               )
                result = dlg.ShowModal()                
                if result == wx.ID_YES:
                    self.OnSave(event)
                    dlg.Destroy()
                elif result == wx.ID_NO:
                    dlg.Destroy()
                else:
                    dlg.Destroy()
                    event.Veto()
                    return
                    break
        text=text+"</workspace>"
        path = homedir+file_sep+"SciPylot"+file_sep+'last_workspace.xml'
        f_idx=path.rfind(file_sep)+1
        self.addGridHistory(path[f_idx:], self.workspace_hist_grid)

        fid=open(path,'w')
        fid.write(text)
        fid.close()                                    
                
        text="<historylist>\n" 
        for row in xrange(self.hist_grid.last_row):
            hist_val=self.hist_grid.GetCellValue(row,0)
            hist_val=hist_val.replace(">","&gt;")
            hist_val=hist_val.replace("<","&lt;")
            time_val=self.hist_grid.GetCellValue(row,1)
            text=text+"<history>"+hist_val+"</history>"
            text=text+"<timestamp>"+time_val+"</timestamp>\n"
        text=text+"</historylist>" 
        path = homedir+file_sep+"SciPylot"+file_sep+'history.xml'
        fid=open(path,'w')
        fid.write(text)
        fid.close()                                    


        text="<historylist>\n" 
        for row in xrange(self.cell_hist_grid.last_row):
            hist_val=self.cell_hist_grid.GetCellValue(row,0)
            hist_val=hist_val.replace(">","&gt;")
            hist_val=hist_val.replace("<","&lt;")
            time_val=self.cell_hist_grid.GetCellValue(row,1)
            text=text+"<history>"+hist_val+"</history>"
            text=text+"<timestamp>"+time_val+"</timestamp>\n"
        text=text+"</historylist>"
        path = homedir+file_sep+"SciPylot"+file_sep+'cell_history.xml'
        fid=open(path,'w')
        fid.write(text)
        fid.close()


        text="<historylist>\n"
        for row in xrange(self.workspace_hist_grid.last_row):
            hist_val=self.workspace_hist_grid.GetCellValue(row,0)
            time_val=self.workspace_hist_grid.GetCellValue(row,1)
            if not hist_val=='last_workspace.xml':
                text=text+"<history>"+hist_val+"</history>"
                text=text+"<timestamp>"+time_val+"</timestamp>\n"
#       last_workspace.xml should only occur once in the history, at the very end
        text=text+"<history>"+hist_val+"</history>"
        text=text+"<timestamp>"+time_val+"</timestamp>\n"

        text=text+"</historylist>" 
        path = homedir+file_sep+"SciPylot"+file_sep+'workspace_history.xml'
        fid=open(path,'w')
        fid.write(text)
        fid.close()                                    

        text="<historylist>\n" 
        for row in xrange(self.file_hist_grid.last_row):
            hist_val=self.file_hist_grid.GetCellValue(row,0)
            time_val=self.file_hist_grid.GetCellValue(row,1)
            text=text+"<history>"+hist_val+"</history>"
            text=text+"<timestamp>"+time_val+"</timestamp>\n"
        text=text+"</historylist>" 
        path = homedir+file_sep+"SciPylot"+file_sep+'file_history.xml'
        fid=open(path,'w')
        fid.write(text)
        fid.close()                                    
        
        if self.destroy_app:
            self._mgr.UnInit()
            del self._mgr
            self.app.ExitMainLoop()
            self.Destroy()
        event.Skip()    


    def OnExit(self, event):
        self.Close()
    def OnClearShell(self,event):
        self.shell.clear()
        self.shell.prompt()
    def OnResetNamespace(self,event):
        self.shell.push('locals().clear()', silent=True, add_hist=False)
        self.shell.push('from namespace import *',silent=True, add_hist=False)
    def OnpySketch(self,event):
        import pySketch
        pySketch.main_from_scipylot()

    def OnExternalHelp(self,event):
        id=event.GetId()
        if wx.Platform == '__WXMSW__'or wx.Platform == '__WXMAC__':
            self.help_notebook.AddPage(page=Html_Viewer(self,-1) , caption = self.help_dict[id][0])
            idx = self.help_notebook.GetPageCount()-1
            page=self.help_notebook.GetPage(idx)
            page.LoadPage(self.help_dict[id][1])
            self.help_notebook.SetSelection(idx)
        else:
            webbrowser.open(self.help_dict[id][1])

        #event.Skip()



    def OnCopy2D(self,event):
        "copy bitmap of canvas to system clipboard"
        cur_fig=namespace.gcf()
        cur_canvas=cur_fig.canvas
        bgcolor   = cur_canvas.figure.get_facecolor()

        cur_canvas.figure.set_facecolor('#FFFFFF')
        namespace.draw()
        bmp_obj = wx.BitmapDataObject()
        bmp_obj.SetBitmap(cur_canvas.bitmap)
        wx.TheClipboard.Open()
        wx.TheClipboard.SetData(bmp_obj)
        wx.TheClipboard.Close()
        cur_canvas.figure.set_facecolor(bgcolor)
        namespace.draw()
        


    def OnClear2D(self,event):
        namespace.clf()
        
    def OnClear3D(self,event):
        namespace.p3d.clf()
        
        
    def OnCopy3D(self,event):
#        handler, name = tempfile.mkstemp()
        name=homedir+file_sep+'junk_bmp_aaaaa.bmp'
        namespace.p3d.savefig(name)
        bmp = wx.Bitmap(name, wx.BITMAP_TYPE_BMP)
        bmpdo = wx.BitmapDataObject(bmp)
        wx.TheClipboard.Open()
        wx.TheClipboard.SetData(bmpdo)
        wx.TheClipboard.Close()
        os.remove(name)
#        os.close(handler)
#        os.unlink(name)



        

    def OnOpenPipeline(self,event):
        namespace.p3d.show_pipeline()


    def OnTemplateLeftDClick(self, event):
        try:
            pt = event.GetPosition();
            item, flags = self.template.HitTest(pt)
            doc=self.nbeditor.GetPage(self.nbeditor.GetSelection())
            file=self.examples.GetPyData(item)
            
            fid = open(file,'r')
            doc.InsertText(doc.GetCurrentPos(),fid.read())
            fid.close()
            event.Skip()
        except:
            event.Skip()

    def OnExamplesLeftDClick(self, event):
        try:
            pt = event.GetPosition();
            item, flags = self.examples.HitTest(pt)
            path=self.examples.GetPyData(item)
#            fid = open(file)
#            self.OnNew(event)
#            doc=self.nbeditor.GetPage(self.nbeditor.GetSelection())

            #do not allow more than one instance of file
    
            if os.path.isfile(path):
                file="EXAMPLE"+os.path.basename(path)
                fid=open(path,'r')
                ftext=fid.read()
                fid.close()
                directory=path[0:path[0:-1].rfind(file_sep)]
                self.OpenEditNotebookPage(directory=directory, name=directory+file_sep+file,caption=file, text=ftext)
                self.Title = 'SciPylot - '+directory+file_sep+file
            else:
                pass








            doc=self.nbeditor.GetPage(0)
#            doc.InsertText(doc.GetCurrentPos(),fid.read())
            doc.SetText(fid.read())
            self.nbeditor.SetSelection(0)
            fid.close()
            event.Skip()
        except:
            event.Skip()



    def OnAbout(self, event):

        msg = """This is SciPylot Version 0.0.0.1\n
        This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
                 Use at your own risk!!!"""
        dlg = wx.MessageDialog(self, msg, "About wx.aui Demo",
                               wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()        


    def GetDockArt(self):

        return self._mgr.GetArtProvider()


    def DoUpdate(self):

        self._mgr.Update()


    def OnEraseBackground(self, event):

        event.Skip()


    def OnSize(self, event):

        event.Skip()


    def OnSettings(self, event):

##        # show the settings pane, and float it
##        floating_pane = self._mgr.GetPane("settings").Float().Show()
##
##        if floating_pane.floating_pos == wx.DefaultPosition:
##            floating_pane.FloatingPosition(self.GetStartPosition())
##
##        self._mgr.Update()
        SettingsFrame(self,self)


    def OnGradient(self, event):

        gradient = 0

        if event.GetId() == ID_NoGradient:
            gradient = wx.aui.AUI_GRADIENT_NONE
        elif event.GetId() == ID_VerticalGradient:
            gradient = wx.aui.AUI_GRADIENT_VERTICAL
        elif event.GetId() == ID_HorizontalGradient:
            gradient = wx.aui.AUI_GRADIENT_HORIZONTAL

        self._mgr.GetArtProvider().SetMetric(wx.aui.AUI_DOCKART_GRADIENT_TYPE, gradient)
        self._mgr.Update()


    def OnManagerFlag(self, event):

        flag = 0
        eid = event.GetId()

        if eid in [ ID_TransparentHint, ID_VenetianBlindsHint, ID_RectangleHint, ID_NoHint ]:
            flags = self._mgr.GetFlags()
            flags &= ~wx.aui.AUI_MGR_TRANSPARENT_HINT
            flags &= ~wx.aui.AUI_MGR_VENETIAN_BLINDS_HINT
            flags &= ~wx.aui.AUI_MGR_RECTANGLE_HINT
            self._mgr.SetFlags(flags)

        if eid == ID_AllowFloating:
            flag = wx.aui.AUI_MGR_ALLOW_FLOATING
        elif eid == ID_TransparentDrag:
            flag = wx.aui.AUI_MGR_TRANSPARENT_DRAG
        elif eid == ID_HintFade:
            flag = wx.aui.AUI_MGR_HINT_FADE
        elif eid == ID_NoVenetianFade:
            flag = wx.aui.AUI_MGR_NO_VENETIAN_BLINDS_FADE
        elif eid == ID_AllowActivePane:
            flag = wx.aui.AUI_MGR_ALLOW_ACTIVE_PANE
        elif eid == ID_TransparentHint:
            flag = wx.aui.AUI_MGR_TRANSPARENT_HINT
        elif eid == ID_VenetianBlindsHint:
            flag = wx.aui.AUI_MGR_VENETIAN_BLINDS_HINT
        elif eid == ID_RectangleHint:
            flag = wx.aui.AUI_MGR_RECTANGLE_HINT
        
        self._mgr.SetFlags(self._mgr.GetFlags() ^ flag)


    def OnUpdateUI(self, event):

        flags = self._mgr.GetFlags()
        eid = event.GetId()
        
        if eid == ID_NoGradient:
            event.Check(self._mgr.GetArtProvider().GetMetric(wx.aui.AUI_DOCKART_GRADIENT_TYPE) == wx.aui.AUI_GRADIENT_NONE)

        elif eid == ID_VerticalGradient:
            event.Check(self._mgr.GetArtProvider().GetMetric(wx.aui.AUI_DOCKART_GRADIENT_TYPE) == wx.aui.AUI_GRADIENT_VERTICAL)

        elif eid == ID_HorizontalGradient:
            event.Check(self._mgr.GetArtProvider().GetMetric(wx.aui.AUI_DOCKART_GRADIENT_TYPE) == wx.aui.AUI_GRADIENT_HORIZONTAL)

        elif eid == ID_AllowFloating:
            event.Check((flags & wx.aui.AUI_MGR_ALLOW_FLOATING) != 0)

        elif eid == ID_TransparentDrag:
            event.Check((flags & wx.aui.AUI_MGR_TRANSPARENT_DRAG) != 0)

        elif eid == ID_TransparentHint:
            event.Check((flags & wx.aui.AUI_MGR_TRANSPARENT_HINT) != 0)

        elif eid == ID_VenetianBlindsHint:
            event.Check((flags & wx.aui.AUI_MGR_VENETIAN_BLINDS_HINT) != 0)

        elif eid == ID_RectangleHint:
            event.Check((flags & wx.aui.AUI_MGR_RECTANGLE_HINT) != 0)

        elif eid == ID_NoHint:
            event.Check(((wx.aui.AUI_MGR_TRANSPARENT_HINT |
                          wx.aui.AUI_MGR_VENETIAN_BLINDS_HINT |
                          wx.aui.AUI_MGR_RECTANGLE_HINT) & flags) == 0)

        elif eid == ID_HintFade:
            event.Check((flags & wx.aui.AUI_MGR_HINT_FADE) != 0);

        elif eid == ID_NoVenetianFade:
            event.Check((flags & wx.aui.AUI_MGR_NO_VENETIAN_BLINDS_FADE) != 0);

                


    def OnCreatePerspective(self, event):

        dlg = wx.TextEntryDialog(self, "Enter a name for the new perspective:", "AUI Test")
        
        dlg.SetValue(("Perspective %d")%(len(self._perspectives)+1))
        if dlg.ShowModal() != wx.ID_OK:
            return
        
        if len(self._perspectives) == 0:
            self._perspectives_menu.AppendSeparator()
        
        self._perspectives_menu.Append(ID_FirstPerspective + len(self._perspectives), dlg.GetValue())
        self._perspectives.append(self._mgr.SavePerspective())
#        print "\n new perspective \n"
#        print self._mgr.SavePerspective().replace(';','\n')


    def OnCopyPerspective(self, event):

        s = self._mgr.SavePerspective()
        
        if wx.TheClipboard.Open():
        
            wx.TheClipboard.SetData(wx.TextDataObject(s))
            wx.TheClipboard.Close()
        
    def OnRestorePerspective(self, event):

        self._mgr.LoadPerspective(self._perspectives[event.GetId() - ID_FirstPerspective])

    def OnMaximizePane(self,event):
#        pane=event.GetPane()
##        self._mgr.GetPane("settings").Hide()
        self._mgr.Update()        
        self.current_layout=self._mgr.SavePerspective()
#        self.current_layout=self._mgr.SavePaneInfo(pane)
#        pane.Right()
        event.Skip()
#        self._mgr.Update()

    def OnRestorePane(self,event):
        event.Skip()
#        self._mgr.GetPane("settings").Hide()
#        self._mgr.Update()


        self.OnRestoreLastPerspective(event)
##        self._mgr.GetPane("settings").Float().Hide()
        self._mgr.Update()        

#

#        event.Veto()
#        pass

#

#        self._mgr.Update()

        
    def GetStartPosition(self):

        self.x = self.x + 20
        x = self.x
        pt = self.ClientToScreen(wx.Point(0, 0))
        
        return wx.Point(pt.x + x, pt.y + x)


    def OnCreateTree(self, event):
        self._mgr.AddPane(self.CreateTreeCtrl(), wx.aui.AuiPaneInfo().
                          Caption("Tree Control").
                          Float().FloatingPosition(self.GetStartPosition()).
                          FloatingSize(wx.Size(150, 300)).CloseButton(True).MaximizeButton(True))
        self._mgr.Update()


    def OnCreateGrid(self, event):
        self._mgr.AddPane(self.CreateGrid(), wx.aui.AuiPaneInfo().
                          Caption("Grid").
                          Float().FloatingPosition(self.GetStartPosition()).
                          FloatingSize(wx.Size(300, 200)).CloseButton(True).MaximizeButton(True))
        self._mgr.Update()


    def OnCreateHTML(self, event):
        self._mgr.AddPane(self.CreateHTMLCtrl(), wx.aui.AuiPaneInfo().
                          Caption("HTML Content").
                          Float().FloatingPosition(self.GetStartPosition()).
                          FloatingSize(wx.Size(300, 200)).CloseButton(True).MaximizeButton(True))
        self._mgr.Update()


    def OnCreateText(self, event):
        self._mgr.AddPane(self.CreateTextCtrl(), wx.aui.AuiPaneInfo().
                          Caption("Text Control").
                          Float().FloatingPosition(self.GetStartPosition()).
                          CloseButton(True).MaximizeButton(True))
        self._mgr.Update()


    def OnCreateSizeReport(self, event):
        self._mgr.AddPane(self.CreateSizeReportCtrl(), wx.aui.AuiPaneInfo().
                          Caption("Client Size Reporter").
                          Float().FloatingPosition(self.GetStartPosition()).
                          CloseButton(True).MaximizeButton(True))
        self._mgr.Update()


    def OnChangeContentPane(self, event):

        self._mgr.GetPane("grid_content").Show(event.GetId() == ID_GridContent)
        self._mgr.GetPane("text_content").Show(event.GetId() == ID_TextContent)
        self._mgr.GetPane("tree_content").Show(event.GetId() == ID_TreeContent)
        self._mgr.GetPane("sizereport_content").Show(event.GetId() == ID_SizeReportContent)
        self._mgr.GetPane("crust_panel").Show(event.GetId() == ID_HTMLContent)
        self._mgr.Update()


    def CreateTextCtrl(self):

        text = ("This is text box %d")%(self.n + 1)

        return wx.TextCtrl(self,-1, text, wx.Point(0, 0), wx.Size(150, 90),
                           wx.NO_BORDER | wx.TE_MULTILINE)

    def CreateCrust(self):
    
        return crust_aui.Crust(self)


    def CreateGrid(self):

        grid = wx.grid.Grid(self, -1, wx.Point(0, 0), wx.Size(150, 250),
                            wx.NO_BORDER | wx.WANTS_CHARS)
        
        grid.CreateGrid(50, 20)

        return grid


    def CreateTreeCtrl(self):

        tree = wx.TreeCtrl(self, -1, wx.Point(0, 0), wx.Size(160, 250),
                           wx.TR_DEFAULT_STYLE | wx.NO_BORDER)
        
        root = tree.AddRoot("AUI Project")
        items = []

        imglist = wx.ImageList(16, 16, True, 2)
        imglist.Add(wx.ArtProvider_GetBitmap(wx.ART_FOLDER, wx.ART_OTHER, wx.Size(16,16)))
        imglist.Add(wx.ArtProvider_GetBitmap(wx.ART_NORMAL_FILE, wx.ART_OTHER, wx.Size(16,16)))
        tree.AssignImageList(imglist)

        items.append(tree.AppendItem(root, "Item 1", 0))
        items.append(tree.AppendItem(root, "Item 2", 0))
        items.append(tree.AppendItem(root, "Item 3", 0))
        items.append(tree.AppendItem(root, "Item 4", 0))
        items.append(tree.AppendItem(root, "Item 5", 0))

        for ii in xrange(len(items)):
        
            id = items[ii]
            tree.AppendItem(id, "Subitem 1", 1)
            tree.AppendItem(id, "Subitem 2", 1)
            tree.AppendItem(id, "Subitem 3", 1)
            tree.AppendItem(id, "Subitem 4", 1)
            tree.AppendItem(id, "Subitem 5", 1)
        
        tree.Expand(root)

        return tree


    def CreateSizeReportCtrl(self, width=80, height=80):

        ctrl = SizeReportCtrl(self, -1, wx.DefaultPosition,
                              wx.Size(width, height), self._mgr)
        return ctrl


    def CreateHTMLCtrl(self):
        ctrl = wx.html.HtmlWindow(self, -1, wx.DefaultPosition, wx.Size(400, 300))
        if "gtk2" in wx.PlatformInfo:
            ctrl.SetStandardFonts()
        ctrl.SetPage(self.GetIntroText()) 
        return ctrl

    def CreateHTMLCtrl2(self):
        ctrl = Html_Viewer(self, -1)
        if "gtk2" in wx.PlatformInfo:
            ctrl.SetStandardFonts()

        ctrl.LoadPage("http://www.wxpython.org")        
               
        return ctrl


    def GetIntroText(self):
        return overview


# -- wx.SizeReportCtrl --
# (a utility control that always reports it's client size)

class SizeReportCtrl(wx.PyControl):

    def __init__(self, parent, id=wx.ID_ANY, pos=wx.DefaultPosition,
                 size=wx.DefaultSize, mgr=None):

        wx.PyControl.__init__(self, parent, id, pos, size, wx.NO_BORDER)
            
        self._mgr = mgr

        self.Bind(wx.EVT_PAINT, self.OnPaint)
        self.Bind(wx.EVT_SIZE, self.OnSize)
        self.Bind(wx.EVT_ERASE_BACKGROUND, self.OnEraseBackground)


    def OnPaint(self, event):

        dc = wx.PaintDC(self)
        
        size = self.GetClientSize()
        s = ("Size: %d x %d")%(size.x, size.y)

        dc.SetFont(wx.NORMAL_FONT)
        w, height = dc.GetTextExtent(s)
        height = height + 3
        dc.SetBrush(wx.WHITE_BRUSH)
        dc.SetPen(wx.WHITE_PEN)
        dc.DrawRectangle(0, 0, size.x, size.y)
        dc.SetPen(wx.LIGHT_GREY_PEN)
        dc.DrawLine(0, 0, size.x, size.y)
        dc.DrawLine(0, size.y, size.x, 0)
        dc.DrawText(s, (size.x-w)/2, ((size.y-(height*5))/2))
        
        if self._mgr:
        
            pi = self._mgr.GetPane(self)
            
            s = ("Layer: %d")%pi.dock_layer
            w, h = dc.GetTextExtent(s)
            dc.DrawText(s, (size.x-w)/2, ((size.y-(height*5))/2)+(height*1))
           
            s = ("Dock: %d Row: %d")%(pi.dock_direction, pi.dock_row)
            w, h = dc.GetTextExtent(s)
            dc.DrawText(s, (size.x-w)/2, ((size.y-(height*5))/2)+(height*2))
            
            s = ("Position: %d")%pi.dock_pos
            w, h = dc.GetTextExtent(s)
            dc.DrawText(s, (size.x-w)/2, ((size.y-(height*5))/2)+(height*3))
            
            s = ("Proportion: %d")%pi.dock_proportion
            w, h = dc.GetTextExtent(s)
            dc.DrawText(s, (size.x-w)/2, ((size.y-(height*5))/2)+(height*4))
        

    def OnEraseBackground(self, event):
        # intentionally empty
        pass        
    

    def OnSize(self, event):
    
        self.Refresh()
        event.Skip()
    

ID_PaneBorderSize = wx.ID_HIGHEST + 1
ID_SashSize = ID_PaneBorderSize + 1
ID_CaptionSize = ID_PaneBorderSize + 2
ID_BackgroundColor = ID_PaneBorderSize + 3
ID_SashColor = ID_PaneBorderSize + 4
ID_InactiveCaptionColor =  ID_PaneBorderSize + 5
ID_InactiveCaptionGradientColor = ID_PaneBorderSize + 6
ID_InactiveCaptionTextColor = ID_PaneBorderSize + 7
ID_ActiveCaptionColor = ID_PaneBorderSize + 8
ID_ActiveCaptionGradientColor = ID_PaneBorderSize + 9
ID_ActiveCaptionTextColor = ID_PaneBorderSize + 10
ID_BorderColor = ID_PaneBorderSize + 11
ID_GripperColor = ID_PaneBorderSize + 12

class SettingsFrame(wx.Frame):
    def __init__(self, parent, frame):    
        wx.Frame.__init__(self, parent, wx.ID_ANY, "SciPylot Layout Settings" , wx.DefaultPosition,size=(475, 300), style = wx.DEFAULT_FRAME_STYLE|wx.STAY_ON_TOP|wx.FULL_REPAINT_ON_RESIZE)    
        SettingsPanel(self,frame)
        self.Show(True)
        
class SettingsPanel(wx.Panel):
    
    def __init__(self, parent, frame):

        wx.Panel.__init__(self, parent, wx.ID_ANY, wx.DefaultPosition,
                          wx.DefaultSize)

        self._frame = frame
        
        vert = wx.BoxSizer(wx.VERTICAL)

        s1 = wx.BoxSizer(wx.HORIZONTAL)
        self._border_size = wx.SpinCtrl(self, ID_PaneBorderSize, "", wx.DefaultPosition, wx.Size(50,20))
        s1.Add((1, 1), 1, wx.EXPAND)
        s1.Add(wx.StaticText(self, -1, "Pane Border Size:"))
        s1.Add(self._border_size)
        s1.Add((1, 1), 1, wx.EXPAND)
        s1.SetItemMinSize(1, (180, 20))
        #vert.Add(s1, 0, wx.EXPAND | wxLEFT | wxBOTTOM, 5)

        s2 = wx.BoxSizer(wx.HORIZONTAL)
        self._sash_size = wx.SpinCtrl(self, ID_SashSize, "", wx.DefaultPosition, wx.Size(50,20))
        s2.Add((1, 1), 1, wx.EXPAND)
        s2.Add(wx.StaticText(self, -1, "Sash Size:"))
        s2.Add(self._sash_size)
        s2.Add((1, 1), 1, wx.EXPAND)
        s2.SetItemMinSize(1, (180, 20))
        #vert.Add(s2, 0, wx.EXPAND | wxLEFT | wxBOTTOM, 5)

        s3 = wx.BoxSizer(wx.HORIZONTAL)
        self._caption_size = wx.SpinCtrl(self, ID_CaptionSize, "", wx.DefaultPosition, wx.Size(50,20))
        s3.Add((1, 1), 1, wx.EXPAND)
        s3.Add(wx.StaticText(self, -1, "Caption Size:"))
        s3.Add(self._caption_size)
        s3.Add((1, 1), 1, wx.EXPAND)
        s3.SetItemMinSize(1, (180, 20))
        #vert.Add(s3, 0, wx.EXPAND | wxLEFT | wxBOTTOM, 5)

        #vert.Add(1, 1, 1, wx.EXPAND)

        b = self.CreateColorBitmap(wx.BLACK)

        s4 = wx.BoxSizer(wx.HORIZONTAL)
        self._background_color = wx.BitmapButton(self, ID_BackgroundColor, b, wx.DefaultPosition, wx.Size(50,25))
        s4.Add((1, 1), 1, wx.EXPAND)
        s4.Add(wx.StaticText(self, -1, "Background Color:"))
        s4.Add(self._background_color)
        s4.Add((1, 1), 1, wx.EXPAND)
        s4.SetItemMinSize(1, (180, 20))

        s5 = wx.BoxSizer(wx.HORIZONTAL)
        self._sash_color = wx.BitmapButton(self, ID_SashColor, b, wx.DefaultPosition, wx.Size(50,25))
        s5.Add((1, 1), 1, wx.EXPAND)
        s5.Add(wx.StaticText(self, -1, "Sash Color:"))
        s5.Add(self._sash_color)
        s5.Add((1, 1), 1, wx.EXPAND)
        s5.SetItemMinSize(1, (180, 20))

        s6 = wx.BoxSizer(wx.HORIZONTAL)
        self._inactive_caption_color = wx.BitmapButton(self, ID_InactiveCaptionColor, b,
                                                       wx.DefaultPosition, wx.Size(50,25))
        s6.Add((1, 1), 1, wx.EXPAND)
        s6.Add(wx.StaticText(self, -1, "Normal Caption:"))
        s6.Add(self._inactive_caption_color)
        s6.Add((1, 1), 1, wx.EXPAND)
        s6.SetItemMinSize(1, (180, 20))

        s7 = wx.BoxSizer(wx.HORIZONTAL)
        self._inactive_caption_gradient_color = wx.BitmapButton(self, ID_InactiveCaptionGradientColor,
                                                                b, wx.DefaultPosition, wx.Size(50,25))
        s7.Add((1, 1), 1, wx.EXPAND)
        s7.Add(wx.StaticText(self, -1, "Normal Caption Gradient:"))
        s7.Add(self._inactive_caption_gradient_color)
        s7.Add((1, 1), 1, wx.EXPAND)
        s7.SetItemMinSize(1, (180, 20))

        s8 = wx.BoxSizer(wx.HORIZONTAL)
        self._inactive_caption_text_color = wx.BitmapButton(self, ID_InactiveCaptionTextColor, b,
                                                            wx.DefaultPosition, wx.Size(50,25))
        s8.Add((1, 1), 1, wx.EXPAND)
        s8.Add(wx.StaticText(self, -1, "Normal Caption Text:"))
        s8.Add(self._inactive_caption_text_color)
        s8.Add((1, 1), 1, wx.EXPAND)
        s8.SetItemMinSize(1, (180, 20))

        s9 = wx.BoxSizer(wx.HORIZONTAL)
        self._active_caption_color = wx.BitmapButton(self, ID_ActiveCaptionColor, b,
                                                     wx.DefaultPosition, wx.Size(50,25))
        s9.Add((1, 1), 1, wx.EXPAND)
        s9.Add(wx.StaticText(self, -1, "Active Caption:"))
        s9.Add(self._active_caption_color)
        s9.Add((1, 1), 1, wx.EXPAND)
        s9.SetItemMinSize(1, (180, 20))

        s10 = wx.BoxSizer(wx.HORIZONTAL)
        self._active_caption_gradient_color = wx.BitmapButton(self, ID_ActiveCaptionGradientColor,
                                                              b, wx.DefaultPosition, wx.Size(50,25))
        s10.Add((1, 1), 1, wx.EXPAND)
        s10.Add(wx.StaticText(self, -1, "Active Caption Gradient:"))
        s10.Add(self._active_caption_gradient_color)
        s10.Add((1, 1), 1, wx.EXPAND)
        s10.SetItemMinSize(1, (180, 20))

        s11 = wx.BoxSizer(wx.HORIZONTAL)
        self._active_caption_text_color = wx.BitmapButton(self, ID_ActiveCaptionTextColor,
                                                          b, wx.DefaultPosition, wx.Size(50,25))
        s11.Add((1, 1), 1, wx.EXPAND)
        s11.Add(wx.StaticText(self, -1, "Active Caption Text:"))
        s11.Add(self._active_caption_text_color)
        s11.Add((1, 1), 1, wx.EXPAND)
        s11.SetItemMinSize(1, (180, 20))

        s12 = wx.BoxSizer(wx.HORIZONTAL)
        self._border_color = wx.BitmapButton(self, ID_BorderColor, b, wx.DefaultPosition,
                                             wx.Size(50,25))
        s12.Add((1, 1), 1, wx.EXPAND)
        s12.Add(wx.StaticText(self, -1, "Border Color:"))
        s12.Add(self._border_color)
        s12.Add((1, 1), 1, wx.EXPAND)
        s12.SetItemMinSize(1, (180, 20))

        s13 = wx.BoxSizer(wx.HORIZONTAL)
        self._gripper_color = wx.BitmapButton(self, ID_GripperColor, b, wx.DefaultPosition,
                                              wx.Size(50,25))
        s13.Add((1, 1), 1, wx.EXPAND)
        s13.Add(wx.StaticText(self, -1, "Gripper Color:"))
        s13.Add(self._gripper_color)
        s13.Add((1, 1), 1, wx.EXPAND)
        s13.SetItemMinSize(1, (180, 20))

        grid_sizer = wx.GridSizer(0, 2)
        grid_sizer.SetHGap(5)
        grid_sizer.Add(s1)
        grid_sizer.Add(s4)
        grid_sizer.Add(s2)
        grid_sizer.Add(s5)
        grid_sizer.Add(s3)
        grid_sizer.Add(s13)
        grid_sizer.Add((1, 1))
        grid_sizer.Add(s12)
        grid_sizer.Add(s6)
        grid_sizer.Add(s9)
        grid_sizer.Add(s7)
        grid_sizer.Add(s10)
        grid_sizer.Add(s8)
        grid_sizer.Add(s11)

        cont_sizer = wx.BoxSizer(wx.VERTICAL)
        cont_sizer.Add(grid_sizer, 1, wx.EXPAND | wx.ALL, 5)
        self.SetSizer(cont_sizer)
        self.GetSizer().SetSizeHints(self)

        self._border_size.SetValue(frame.GetDockArt().GetMetric(wx.aui.AUI_DOCKART_PANE_BORDER_SIZE))
        self._sash_size.SetValue(frame.GetDockArt().GetMetric(wx.aui.AUI_DOCKART_SASH_SIZE))
        self._caption_size.SetValue(frame.GetDockArt().GetMetric(wx.aui.AUI_DOCKART_CAPTION_SIZE))

        self.UpdateColors()

        self.Bind(wx.EVT_SPINCTRL, self.OnPaneBorderSize, id=ID_PaneBorderSize)
        self.Bind(wx.EVT_SPINCTRL, self.OnSashSize, id=ID_SashSize)
        self.Bind(wx.EVT_SPINCTRL, self.OnCaptionSize, id=ID_CaptionSize)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_BackgroundColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_SashColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_InactiveCaptionColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_InactiveCaptionGradientColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_InactiveCaptionTextColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_ActiveCaptionColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_ActiveCaptionGradientColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_ActiveCaptionTextColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_BorderColor)
        self.Bind(wx.EVT_BUTTON, self.OnSetColor, id=ID_GripperColor)


    def CreateColorBitmap(self, c):
        image = wx.EmptyImage(25, 14)

        for x in xrange(25):
            for y in xrange(14):
                pixcol = c
                if x == 0 or x == 24 or y == 0 or y == 13:
                    pixcol = wx.BLACK

                image.SetRGB(x, y, pixcol.Red(), pixcol.Green(), pixcol.Blue())

        return image.ConvertToBitmap()


    def UpdateColors(self):

        bk = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_BACKGROUND_COLOUR)
        self._background_color.SetBitmapLabel(self.CreateColorBitmap(bk))

        cap = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_INACTIVE_CAPTION_COLOUR)
        self._inactive_caption_color.SetBitmapLabel(self.CreateColorBitmap(cap))

        capgrad = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_INACTIVE_CAPTION_GRADIENT_COLOUR)
        self._inactive_caption_gradient_color.SetBitmapLabel(self.CreateColorBitmap(capgrad))

        captxt = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_INACTIVE_CAPTION_TEXT_COLOUR)
        self._inactive_caption_text_color.SetBitmapLabel(self.CreateColorBitmap(captxt))

        acap = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_ACTIVE_CAPTION_COLOUR)
        self._active_caption_color.SetBitmapLabel(self.CreateColorBitmap(acap))

        acapgrad = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_ACTIVE_CAPTION_GRADIENT_COLOUR)
        self._active_caption_gradient_color.SetBitmapLabel(self.CreateColorBitmap(acapgrad))

        acaptxt = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_ACTIVE_CAPTION_TEXT_COLOUR)
        self._active_caption_text_color.SetBitmapLabel(self.CreateColorBitmap(acaptxt))

        sash = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_SASH_COLOUR)
        self._sash_color.SetBitmapLabel(self.CreateColorBitmap(sash))

        border = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_BORDER_COLOUR)
        self._border_color.SetBitmapLabel(self.CreateColorBitmap(border))

        gripper = self._frame.GetDockArt().GetColour(wx.aui.AUI_DOCKART_GRIPPER_COLOUR)
        self._gripper_color.SetBitmapLabel(self.CreateColorBitmap(gripper))


    def OnPaneBorderSize(self, event):

        self._frame.GetDockArt().SetMetric(wx.aui.AUI_DOCKART_PANE_BORDER_SIZE,
                                           event.GetInt())
        self._frame.DoUpdate()


    def OnSashSize(self, event):

        self._frame.GetDockArt().SetMetric(wx.aui.AUI_DOCKART_SASH_SIZE,
                                           event.GetInt())
        self._frame.DoUpdate()


    def OnCaptionSize(self, event):

        self._frame.GetDockArt().SetMetric(wx.aui.AUI_DOCKART_CAPTION_SIZE,
                                           event.GetInt())
        self._frame.DoUpdate()


    def OnSetColor(self, event):

        dlg = wx.ColourDialog(self)#(self._frame)

        dlg.SetTitle("Color Picker")

        if dlg.ShowModal() != wx.ID_OK:
            return
        
        var = 0
        if event.GetId() == ID_BackgroundColor:
            var = wx.aui.AUI_DOCKART_BACKGROUND_COLOUR
        elif event.GetId() == ID_SashColor:
            var = wx.aui.AUI_DOCKART_SASH_COLOUR
        elif event.GetId() == ID_InactiveCaptionColor:
            var = wx.aui.AUI_DOCKART_INACTIVE_CAPTION_COLOUR
        elif event.GetId() == ID_InactiveCaptionGradientColor:
            var = wx.aui.AUI_DOCKART_INACTIVE_CAPTION_GRADIENT_COLOUR
        elif event.GetId() == ID_InactiveCaptionTextColor:
            var = wx.aui.AUI_DOCKART_INACTIVE_CAPTION_TEXT_COLOUR
        elif event.GetId() == ID_ActiveCaptionColor:
            var = wx.aui.AUI_DOCKART_ACTIVE_CAPTION_COLOUR
        elif event.GetId() == ID_ActiveCaptionGradientColor:
            var = wx.aui.AUI_DOCKART_ACTIVE_CAPTION_GRADIENT_COLOUR
        elif event.GetId() == ID_ActiveCaptionTextColor:
            var = wx.aui.AUI_DOCKART_ACTIVE_CAPTION_TEXT_COLOUR
        elif event.GetId() == ID_BorderColor:
            var = wx.aui.AUI_DOCKART_BORDER_COLOUR
        elif event.GetId() == ID_GripperColor:
            var = wx.aui.AUI_DOCKART_GRIPPER_COLOUR
        else:
            return        
        
        self._frame.GetDockArt().SetColor(var, dlg.GetColourData().GetColour())
        self._frame.DoUpdate()
        self.UpdateColors()



#----------------------------------------------------------------------

class TestPanel(wx.Panel):
    def __init__(self, parent):
#        self.log = log
        wx.Panel.__init__(self, parent, -1)
        b = wx.Button(self, -1, "Show the wx.aui Demo Frame", (50,50))
        self.Bind(wx.EVT_BUTTON, self.OnButton, b)

    def OnButton(self, evt):
        frame = PyAUIFrame(self, wx.ID_ANY, "wx.aui wxPython Demo", size=(1200, 800))
        frame.Show()

#----------------------------------------------------------------------

def runTest(frame, nb, log):
    win = TestPanel(nb, log)
    return win

#----------------------------------------------------------------------
class MyApp(wx.App):
    def OnInit(self):
        try:
           fname = homedir+file_sep+"SciPylot"+file_sep+'last_workspace.xml'
           the_layout=[]
           parse(fname, GeneralXMLHandler(the_layout,'layout'))
           the_files=[]
           parse(fname, GeneralXMLHandler(the_files,'file'))
           the_frame_size=[]
           parse(fname, GeneralXMLHandler(the_frame_size,'framesize'))
           the_position=[]
           parse(fname, GeneralXMLHandler(the_position,'position'))
           exec("(width,height)="+the_frame_size[0])
           exec("(from_left,from_top)="+the_position[0])

           size=wx.Size(width,height)
           position=wx.Point(from_left,from_top)
           layout=the_layout[0]
        except:
            size=(950, 760)
            position=wx.Point(100,100)
            layout=default_layout

        frame = PyAUIFrame(None, wx.ID_ANY, "SciPylot", size=size, pos=position,layout=layout, app=self)
        frame.Show(True)
            
        return True




overview = """\
<html><body>
<h3>wx.aui, the Advanced User Interface module</h3>

<br/><b>Overview</b><br/>

<p>wx.aui is an Advanced User Interface library for the wxWidgets toolkit 
that allows developers to create high-quality, cross-platform user 
interfaces quickly and easily.</p>

<p><b>Features</b></p>

<p>With wx.aui developers can create application frameworks with:</p>

<ul>
<li>Native, dockable floating frames</li>
<li>Perspective saving and loading</li>
<li>Native toolbars incorporating real-time, &quot;spring-loaded&quot; dragging</li>
<li>Customizable floating/docking behavior</li>
<li>Completely customizable look-and-feel</li>
<li>Optional transparent window effects (while dragging or docking)</li>
</ul>

</body></html>
"""




#if __name__ == '__main__':
if True:
    if wx.GetApp()==None:
        Create_App=True
    elif wx.GetApp().IsMainLoopRunning():
        Create_App=False
    else:
        Create_App=True


    if Create_App:
#        app = MyApp(0)
        app = MyApp(0)#redirect=True,filename='junk_out.txt')
        app.MainLoop()
    else:
        destroy_app=False
        frame2 = PyAUIFrame(None, wx.ID_ANY, "SciPylot2", destroy_app=False,size=(950, 760))
        frame2.Show(True)




