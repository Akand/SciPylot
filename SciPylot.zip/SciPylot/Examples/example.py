First initiate the SciPylot window. Here we will show how to run "hello.py" in SciPylot. Write the following file in SciPylot inputcell. 

********************hello.py*****************
            print "Hello World"

*********************************************

Save this file in Scipylot directory or anywhere in your computer.

Go to File/Open or click on "Open File" menubar in order to open "hello.py". Now run this file by clicking on F5 or go to "Run File in Shell" or "Run Externally". "Run Externally" will execute in command prompt. 
