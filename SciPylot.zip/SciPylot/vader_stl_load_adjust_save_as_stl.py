mesh=darthstl.get_output()
vader_points=mesh.points.to_array()
from enthought.tvtk.api import tvtk
import numpy as np

darthstl=tvtk.STLReader()
darthstl.file_name=r"C:\Downloads\vader3ds.stl"
darthstl.update()

mesh=darthstl.get_output()


#to get the triangle connections
vader_polys=np.array(mesh.polys.data)
vader_polys=np.reshape(vader_polys,[len(vader_polys)/4,4])
vader_polys=vader_polys[:,1:4]

s1=shape(vader_points)
p1 = array(abs(vader_points[:,0])>.2345 ) 
vader_points[p1,0]=vader_points[p1,0]*(1+(((vader_points[p1,2]+.42)/(-1.18+.42))**1*(.2345/.385-1.0)))

mesh = tvtk.PolyData(points=vader_points, polys=vader_polys)
#mesh.point_data.scalars.name = 'Temperature'
src = VTKDataSource(data = mesh)
e=p3d.get_engine()
e.add_source(src)
#s = Surface()
#e.add_module(s)
p3d.pipeline.surface(src,opacity=1.0)#, color=colors.ivory)

#output stl ASCII file
stl_out=tvtk.STLWriter(file_name=r"C:\Downloads\vader_adjusted.stl")
stl_out.set_input(mesh)
stl_out.write()

